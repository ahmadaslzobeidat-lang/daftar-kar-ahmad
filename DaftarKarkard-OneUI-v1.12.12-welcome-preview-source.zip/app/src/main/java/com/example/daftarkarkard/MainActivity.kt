package com.example.daftarkarkard

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import java.util.concurrent.Executor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

data class Worker(val id: Long, val name: String, val currency: String = "دینار",
    val surname: String = "", val age: Int = 0, val phone: String = "", val photoUri: String = "") {
    val fullName: String get() = listOf(name.trim(),surname.trim()).filter { it.isNotBlank() }.joinToString(" ")
}
data class Project(val id: Long, val name: String, val currency: String = "دینار", val country: String = "عراق", val accentColor:Int = 0)
data class ProjectExpense(val id: Long, val date: String, val category: String, val amount: Long, val note: String)
data class ProjectMaterial(val id: Long, val date: String, val name: String, val quantity: Double, val unit: String, val unitPrice: Long, val note: String)
data class Work(val id: Long, val workerId: Long, val date: String, val start: String, val end: String,
                val wage: Long, val overtime: Double, val note: String, val projectId: Long? = null, val extraAmount: Long = 0L)
data class Payment(val id: Long, val workerId: Long, val date: String, val amount: Long, val note: String, val projectId: Long? = null)

class Db(context: Context) : SQLiteOpenHelper(context, "daftar_native.db", null, 6) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, currency TEXT NOT NULL DEFAULT 'دینار', surname TEXT NOT NULL DEFAULT '', age INTEGER NOT NULL DEFAULT 0, phone TEXT NOT NULL DEFAULT '', photo_uri TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE works(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, date TEXT NOT NULL, start TEXT, end TEXT, wage INTEGER NOT NULL, overtime REAL NOT NULL DEFAULT 0, note TEXT, project_id INTEGER)")
        db.execSQL("CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, currency TEXT NOT NULL DEFAULT 'دینار')")
        db.execSQL("CREATE TABLE project_expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT)")
        db.execSQL("CREATE TABLE project_materials(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, unit_price INTEGER NOT NULL, note TEXT)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, date TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, project_id INTEGER)")
        db.execSQL("ALTER TABLE projects ADD COLUMN country TEXT NOT NULL DEFAULT 'عراق'")
        db.execSQL("ALTER TABLE works ADD COLUMN extra_amount INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE projects ADD COLUMN accent_color INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE TABLE project_expense_categories(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
        db.execSQL("CREATE TABLE project_material_names(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
    }
    private fun hasColumn(db:SQLiteDatabase, table:String, column:String):Boolean {
        db.rawQuery("PRAGMA table_info($table)",null).use { c ->
            val nameIndex=c.getColumnIndex("name")
            while(c.moveToNext()) if(nameIndex>=0 && c.getString(nameIndex)==column) return true
        }
        return false
    }
    private fun ensureColumn(db:SQLiteDatabase, table:String, column:String, declaration:String) {
        if(!hasColumn(db,table,column)) db.execSQL("ALTER TABLE $table ADD COLUMN $column $declaration")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Idempotent migrations are important when importing backups made by older app builds.
        db.execSQL("CREATE TABLE IF NOT EXISTS workers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, currency TEXT NOT NULL DEFAULT 'دینار')")
        db.execSQL("CREATE TABLE IF NOT EXISTS works(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, date TEXT NOT NULL, start TEXT, end TEXT, wage INTEGER NOT NULL, overtime REAL NOT NULL DEFAULT 0, note TEXT, project_id INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, date TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, project_id INTEGER)")
        ensureColumn(db,"workers","currency","TEXT NOT NULL DEFAULT 'دینار'")
        ensureColumn(db,"workers","surname","TEXT NOT NULL DEFAULT ''")
        ensureColumn(db,"workers","age","INTEGER NOT NULL DEFAULT 0")
        ensureColumn(db,"workers","phone","TEXT NOT NULL DEFAULT ''")
        ensureColumn(db,"workers","photo_uri","TEXT NOT NULL DEFAULT ''")
        ensureColumn(db,"works","project_id","INTEGER")
        ensureColumn(db,"payments","project_id","INTEGER")
        ensureColumn(db,"projects","currency","TEXT NOT NULL DEFAULT 'دینار'")
        db.execSQL("CREATE TABLE IF NOT EXISTS project_expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS project_materials(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, unit_price INTEGER NOT NULL, note TEXT)")
        ensureColumn(db,"projects","country","TEXT NOT NULL DEFAULT 'عراق'")
        ensureColumn(db,"works","extra_amount","INTEGER NOT NULL DEFAULT 0")
        ensureColumn(db,"projects","accent_color","INTEGER NOT NULL DEFAULT 0")
        db.execSQL("UPDATE projects SET country=CASE WHEN currency='ریال' THEN 'ایران' ELSE 'عراق' END WHERE country IS NULL OR country=''")
        db.execSQL("CREATE TABLE IF NOT EXISTS project_expense_categories(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS project_material_names(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
    }
    fun projects():List<Project> {
        val out= mutableListOf<Project>()
        readableDatabase.rawQuery("SELECT id,name,currency,country,accent_color FROM projects ORDER BY name",null).use { c -> while(c.moveToNext()) out += Project(c.getLong(0),c.getString(1),c.getString(2) ?: "دینار",c.getString(3) ?: "عراق",c.getInt(4)) }
        return out
    }
    fun addProject(name:String,currency:String,country:String,accentColor:Int=0) { writableDatabase.execSQL("INSERT INTO projects(name,currency,country,accent_color) VALUES(?,?,?,?)", arrayOf(name.trim(),currency,country,accentColor)) }
    fun renameProject(id:Long,name:String,currency:String,country:String,accentColor:Int=0) { writableDatabase.execSQL("UPDATE projects SET name=?,currency=?,country=?,accent_color=? WHERE id=?",arrayOf(name.trim(),currency,country,accentColor,id)) }
    fun deleteProject(id:Long) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.execSQL("UPDATE works SET project_id=NULL WHERE project_id=?",arrayOf(id))
            writableDatabase.execSQL("UPDATE payments SET project_id=NULL WHERE project_id=?",arrayOf(id))
            writableDatabase.delete("project_expenses","project_id=?",arrayOf(id.toString()))
            writableDatabase.delete("project_materials","project_id=?",arrayOf(id.toString()))
            writableDatabase.delete("projects","id=?",arrayOf(id.toString()))
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun addProjectExpense(projectId:Long,date:String,category:String,amount:Long,note:String) { writableDatabase.execSQL("INSERT INTO project_expenses(project_id,date,category,amount,note) VALUES(?,?,?,?,?)",arrayOf(projectId,date,category,amount,note)) }
    fun projectExpenses(projectId:Long):List<ProjectExpense> { val a=mutableListOf<ProjectExpense>(); readableDatabase.rawQuery("SELECT id,date,category,amount,note FROM project_expenses WHERE project_id=? ORDER BY date DESC",arrayOf(projectId.toString())).use { c -> while(c.moveToNext()) a += ProjectExpense(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getString(4) ?: "") }; return a }
    fun addProjectMaterial(projectId:Long,date:String,name:String,quantity:Double,unit:String,unitPrice:Long,note:String) { writableDatabase.execSQL("INSERT INTO project_materials(project_id,date,name,quantity,unit,unit_price,note) VALUES(?,?,?,?,?,?,?)",arrayOf(projectId,date,name,quantity,unit,unitPrice,note)) }
    fun projectMaterials(projectId:Long):List<ProjectMaterial> { val a=mutableListOf<ProjectMaterial>(); readableDatabase.rawQuery("SELECT id,date,name,quantity,unit,unit_price,note FROM project_materials WHERE project_id=? ORDER BY date DESC",arrayOf(projectId.toString())).use { c -> while(c.moveToNext()) a += ProjectMaterial(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4),c.getLong(5),c.getString(6) ?: "") }; return a }
    fun catalog(table:String):List<String> {
        val safe=if(table=="project_material_names") "project_material_names" else "project_expense_categories"
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM $safe ORDER BY name",null).use { c -> while(c.moveToNext()) out += c.getString(0) }
        return out
    }
    fun saveCatalog(table:String,name:String) {
        val safe=if(table=="project_material_names") "project_material_names" else "project_expense_categories"
        writableDatabase.execSQL("INSERT OR IGNORE INTO $safe(name) VALUES(?)",arrayOf(name.trim()))
    }
    fun projectName(id:Long?):String = if(id==null) "بدون پروژه" else projects().firstOrNull{it.id==id}?.name ?: "پروژه حذف‌شده"
    fun projectWorks(id:Long):List<Work> = allWorks().filter { it.projectId==id }
    fun projectWorkers(id:Long):List<Long> = projectWorks(id).map{it.workerId}.distinct()
    fun workers(): List<Worker> {
        val out= mutableListOf<Worker>()
        readableDatabase.rawQuery("SELECT id,name,currency,surname,age,phone,photo_uri FROM workers ORDER BY name,surname",null).use { c ->
            while(c.moveToNext()) out += Worker(c.getLong(0),c.getString(1),c.getString(2) ?: "دینار",c.getString(3) ?: "",c.getInt(4),c.getString(5) ?: "",c.getString(6) ?: "")
        }
        return out
    }
    fun addWorker(name:String,currency:String,surname:String="",age:Int=0,phone:String="",photoUri:String="") {
        writableDatabase.execSQL("INSERT INTO workers(name,currency,surname,age,phone,photo_uri) VALUES(?,?,?,?,?,?)", arrayOf(name.trim(),currency,surname.trim(),age,phone.trim(),photoUri))
    }
    fun updateWorker(id:Long,name:String,currency:String,surname:String,age:Int,phone:String,photoUri:String) {
        writableDatabase.execSQL("UPDATE workers SET name=?,currency=?,surname=?,age=?,phone=?,photo_uri=? WHERE id=?",arrayOf(name.trim(),currency,surname.trim(),age,phone.trim(),photoUri,id))
    }
    fun deleteWorker(id:Long) { writableDatabase.beginTransaction(); try { writableDatabase.delete("works","worker_id=?", arrayOf(id.toString())); writableDatabase.delete("payments","worker_id=?", arrayOf(id.toString())); writableDatabase.delete("workers","id=?",arrayOf(id.toString())); writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() } }
    fun works(worker:Long):List<Work> { val a= mutableListOf<Work>(); readableDatabase.rawQuery("SELECT id,worker_id,date,start,end,wage,overtime,note,project_id,extra_amount FROM works WHERE worker_id=? ORDER BY date DESC,id DESC",arrayOf(worker.toString())).use { c -> while(c.moveToNext()) a += Work(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3)?: "",c.getString(4)?: "",c.getLong(5),c.getDouble(6),c.getString(7)?: "",if(c.isNull(8)) null else c.getLong(8),c.getLong(9)) }; return a }
    fun allWorks():List<Work> = workers().flatMap { works(it.id) }
    fun addWorks(ids:List<Long>, date:String, start:String, end:String, wage:Long, ot:Double, note:String, projectId:Long?=null, extraAmount:Long=0L) {
        writableDatabase.beginTransaction(); try { ids.forEach { writableDatabase.execSQL("INSERT INTO works(worker_id,date,start,end,wage,overtime,note,project_id,extra_amount) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(it,date,start,end,wage,ot,note,projectId,extraAmount)) }; writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() }
    }
    fun updateWork(w:Work) { writableDatabase.execSQL("UPDATE works SET date=?,start=?,end=?,wage=?,overtime=?,note=?,project_id=?,extra_amount=? WHERE id=?",arrayOf(w.date,w.start,w.end,w.wage,w.overtime,w.note,w.projectId,w.extraAmount,w.id)) }
    fun deleteWork(id:Long) { writableDatabase.delete("works","id=?",arrayOf(id.toString())) }
    fun payments(worker:Long):List<Payment> { val a= mutableListOf<Payment>(); readableDatabase.rawQuery("SELECT id,worker_id,date,amount,note,project_id FROM payments WHERE worker_id=? ORDER BY date DESC",arrayOf(worker.toString())).use { c -> while(c.moveToNext()) a += Payment(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4)?: "",if(c.isNull(5)) null else c.getLong(5)) }; return a }
    fun addPayment(worker:Long,date:String,amount:Long,note:String,projectId:Long?=null) { writableDatabase.execSQL("INSERT INTO payments(worker_id,date,amount,note,project_id) VALUES(?,?,?,?,?)",arrayOf(worker,date,amount,note,projectId)) }
    fun projectPaid(projectId:Long):Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE project_id=?",arrayOf(projectId.toString())).use { c -> if(c.moveToFirst()) c.getLong(0) else 0L }
    fun projectPayments(projectId:Long):List<Payment> {
        val out=mutableListOf<Payment>()
        readableDatabase.rawQuery("SELECT id,worker_id,date,amount,note,project_id FROM payments WHERE project_id=? ORDER BY date DESC",arrayOf(projectId.toString())).use { c ->
            while(c.moveToNext()) out += Payment(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4)?: "",if(c.isNull(5)) null else c.getLong(5))
        }
        return out
    }
    fun deletePayment(id:Long) { writableDatabase.delete("payments","id=?",arrayOf(id.toString())) }
    fun total(worker:Long):Long = works(worker).filterNot { it.note.trim()=="تعطیل" }.sumOf { it.wage + (it.wage*it.overtime/8.0).toLong() + it.extraAmount }
    fun paid(worker:Long):Long = payments(worker).sumOf { it.amount }
}


private class CircularCropView(context: android.content.Context, private val source: Bitmap) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val matrix = Matrix()
    private val scaleDetector = android.view.ScaleGestureDetector(context, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: android.view.ScaleGestureDetector): Boolean {
            matrix.postScale(detector.scaleFactor, detector.scaleFactor, detector.focusX, detector.focusY)
            invalidate()
            return true
        }
    })
    private var lastX = 0f
    private var lastY = 0f
    private var initialized = false
    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }
    override fun onSizeChanged(w:Int,h:Int,oldw:Int,oldh:Int) {
        super.onSizeChanged(w,h,oldw,oldh)
        val side = minOf(w,h).toFloat()
        val scale = side / minOf(source.width, source.height).toFloat()
        matrix.setScale(scale,scale)
        val values=FloatArray(9); matrix.getValues(values)
        matrix.postTranslate((w-source.width*scale)/2f,(h-source.height*scale)/2f)
        initialized=true
    }
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        if(!initialized) return
        val side=minOf(width,height).toFloat()
        val left=(width-side)/2f; val top=(height-side)/2f
        val save=canvas.save()
        canvas.drawColor(Color.rgb(22,24,31))
        val circlePath=Path().apply { addCircle(left+side/2f,top+side/2f,side/2f,Path.Direction.CW) }
        canvas.clipPath(circlePath)
        canvas.drawBitmap(source,matrix,paint)
        canvas.restoreToCount(save)
        val shade=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.argb(145,0,0,0); style=Paint.Style.STROKE; strokeWidth=dpLocal(2f) }
        canvas.drawCircle(left+side/2f,top+side/2f,side/2f-dpLocal(1f),shade)
    }
    private fun dpLocal(v:Float)=v*resources.displayMetrics.density
    override fun onTouchEvent(event:android.view.MotionEvent):Boolean {
        scaleDetector.onTouchEvent(event)
        when(event.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { lastX=event.x; lastY=event.y; return true }
            android.view.MotionEvent.ACTION_MOVE -> if(!scaleDetector.isInProgress) {
                val dx=event.x-lastX; val dy=event.y-lastY
                matrix.postTranslate(dx,dy); lastX=event.x; lastY=event.y; invalidate(); return true
            }
        }
        return true
    }
    fun cropped():Bitmap {
        val side=minOf(width,height).toFloat()
        val left=(width-side)/2f; val top=(height-side)/2f
        val out=Bitmap.createBitmap(512,512,Bitmap.Config.ARGB_8888)
        val c=Canvas(out)
        val path=Path().apply { addCircle(256f,256f,256f,Path.Direction.CW) }
        c.clipPath(path)
        val transform=Matrix(matrix)
        transform.postTranslate(-left,-top)
        transform.postScale(512f/side,512f/side)
        c.drawBitmap(source,transform,paint)
        return out
    }
}

class MainActivity : FragmentActivity() {
    private lateinit var db: Db
    private lateinit var content: LinearLayout
    private var workerPhotoPickerCallback: ((Bitmap?) -> Unit)? = null
    // Theme palette follows the supplied dark/light reference screens.
    private var isDarkTheme=true
    private var green=Color.rgb(154,108,235)        // semantic: work amount (purple)
    private var workColor=Color.rgb(154,108,235)
    private var balanceColor=Color.rgb(54,164,105)
    private var headerPurple=Color.rgb(21,23,42)
    private var teal=Color.rgb(51,190,169)
    private var canvasColor=Color.rgb(16,17,22)
    private var ink=Color.rgb(246,247,249)
    private var muted=Color.rgb(164,168,178)
    private var red=Color.rgb(255,59,48)            // semantic: received amount
    private var blue=Color.rgb(190,245,44)
    private var surface=Color.rgb(27,28,34)
    private var surfaceAlt=Color.rgb(36,38,46)
    private var outline=Color.rgb(47,49,58)
    private fun applyThemeColors() {
        isDarkTheme=prefs.getBoolean("dark_mode",true)
        if(isDarkTheme) {
            canvasColor=Color.rgb(16,17,22); headerPurple=Color.rgb(19,21,39)
            surface=Color.rgb(27,28,34); surfaceAlt=Color.rgb(37,39,47); outline=Color.rgb(48,51,61)
            ink=Color.rgb(246,247,249); muted=Color.rgb(166,170,180)
            blue=Color.rgb(48,143,226); teal=Color.rgb(54,193,171)
            red=Color.rgb(255,59,48); workColor=Color.rgb(155,108,235)
            balanceColor=Color.rgb(54,164,105); green=workColor
        } else {
            canvasColor=Color.rgb(246,246,247); headerPurple=Color.rgb(246,247,249)
            surface=Color.rgb(255,255,255); surfaceAlt=Color.rgb(239,243,248); outline=Color.rgb(184,193,205)
            ink=Color.rgb(78,83,92); muted=Color.rgb(105,111,121)
            blue=Color.rgb(31,111,190); teal=Color.rgb(51,157,143)
            red=Color.rgb(255,59,48); workColor=Color.rgb(132,82,205)
            balanceColor=Color.rgb(47,139,86); green=workColor
        }
    }
    private val prefs by lazy { getSharedPreferences("ui_settings", MODE_PRIVATE) }
    private fun currency() = prefs.getString("currency", "دینار") ?: "دینار"
    private fun jalali() = prefs.getBoolean("jalali", false)
    private fun ownerName():String = prefs.getString("owner_name","")?.trim().orEmpty()
    private fun askOwnerName() {
        val dialogBg=if(isDarkTheme) Color.rgb(29,31,43) else Color.rgb(250,251,255)
        val fieldBg=if(isDarkTheme) Color.rgb(43,46,62) else Color.rgb(255,255,255)
        val titleColor=if(isDarkTheme) Color.rgb(248,249,255) else Color.rgb(25,31,48)
        val bodyColor=if(isDarkTheme) Color.rgb(190,195,211) else Color.rgb(92,101,119)
        val accent=if(isDarkTheme) Color.rgb(48,143,226) else Color.rgb(20,105,224)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER_HORIZONTAL
            setPadding(dp(22),dp(22),dp(22),dp(20))
            background=android.graphics.drawable.GradientDrawable().apply {
                setColor(dialogBg)
                cornerRadius=dp(28).toFloat()
                setStroke(dp(1),if(isDarkTheme) Color.rgb(65,72,99) else Color.rgb(220,226,239))
            }
        }
        val iconTile=FrameLayout(this).apply {
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(if(isDarkTheme) Color.rgb(62,100,225) else Color.rgb(47,142,245),
                    if(isDarkTheme) Color.rgb(35,68,172) else Color.rgb(13,82,210))
            ).apply { cornerRadius=dp(22).toFloat() }
            elevation=dp(3).toFloat()
        }
        val hardhat=ImageView(this).apply {
            setImageResource(R.drawable.helmet_icon_crop)
            scaleType=ImageView.ScaleType.CENTER_CROP
            contentDescription="کلاه ایمنی"
        }
        iconTile.addView(hardhat,FrameLayout.LayoutParams(-1,-1))
        root.addView(iconTile,LinearLayout.LayoutParams(dp(76),dp(76)).apply {
            gravity=Gravity.CENTER_HORIZONTAL
            bottomMargin=dp(15)
        })
        val heading=TextView(this).apply {
            text="خوش آمدید"
            textSize=23f
            setTextColor(titleColor)
            typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD)
            gravity=Gravity.CENTER
            includeFontPadding=false
        }
        root.addView(heading,LinearLayout.LayoutParams(-1,dp(38)))
        val subtitle=TextView(this).apply {
            text="برای شروع، نام خود را وارد کنید."
            textSize=14f
            setTextColor(bodyColor)
            gravity=Gravity.CENTER
            includeFontPadding=false
        }
        root.addView(subtitle,LinearLayout.LayoutParams(-1,dp(34)))
        val nameInput=EditText(this).apply {
            hint="نام و نام خانوادگی"
            isSingleLine=true
            setText(ownerName())
            textDirection=View.TEXT_DIRECTION_RTL
            gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textSize=16f
            setTextColor(titleColor)
            setHintTextColor(if(isDarkTheme) Color.rgb(151,158,178) else Color.rgb(132,141,158))
            setPadding(dp(15),dp(12),dp(15),dp(12))
            background=android.graphics.drawable.GradientDrawable().apply {
                setColor(fieldBg)
                cornerRadius=dp(16).toFloat()
                setStroke(dp(1),if(isDarkTheme) Color.rgb(76,84,112) else Color.rgb(183,197,225))
            }
        }
        root.addView(nameInput,LinearLayout.LayoutParams(-1,dp(56)).apply {
            topMargin=dp(13)
            bottomMargin=dp(17)
        })
        val continueButton=Button(this).apply {
            text="ادامه"
            isAllCaps=false
            textSize=16f
            typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(accent,if(isDarkTheme) Color.rgb(35,83,205) else Color.rgb(0,64,190))
            ).apply { cornerRadius=dp(17).toFloat() }
            elevation=dp(2).toFloat()
            minHeight=dp(54)
        }
        root.addView(continueButton,LinearLayout.LayoutParams(-1,dp(54)))
        val dialog=AlertDialog.Builder(this).setView(root).setCancelable(false).create()
        continueButton.setOnClickListener {
            val value=nameInput.text.toString().trim()
            if(value.isBlank()) {
                nameInput.error="لطفاً نام و نام خانوادگی را وارد کنید"
                nameInput.requestFocus()
                return@setOnClickListener
            }
            prefs.edit().putString("owner_name",value).apply()
            dialog.dismiss()
            if(prefs.getBoolean("biometric",false)) authenticate() else showHome()
        }
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setDimAmount(0.55f)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels-dp(40)), -2)
            nameInput.requestFocus()
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels-dp(40)), -2)
    }
    private var currentWorker:Worker?=null
    private var currentBack:()->Unit = { showHome() }
    private var isDashboardPage:Boolean = true
    private val backupReq=501
    private val restoreReq=502

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep app content between the system bars so the header and bottom navigation
        // are never hidden behind Android's status/navigation bars (Android 15+ too).
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val appLang=prefs.getString("app_language","fa") ?: "fa"
        val locale=Locale.forLanguageTag(appLang)
        Locale.setDefault(locale)
        @Suppress("DEPRECATION")
        resources.updateConfiguration(resources.configuration.apply { setLocale(locale) },resources.displayMetrics)
        applyThemeColors()
        updateSystemBars()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        db=Db(this)
        if(ownerName().isBlank()) askOwnerName()
        else if(prefs.getBoolean("biometric",false)) authenticate() else showHome()
    }

    private fun updateSystemBars() {
        window.statusBarColor=canvasColor
        window.navigationBarColor=canvasColor
        val flags=if(isDarkTheme) 0 else
            (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        window.decorView.systemUiVisibility=flags
        if(android.os.Build.VERSION.SDK_INT>=29) {
            window.isStatusBarContrastEnforced=false
            window.isNavigationBarContrastEnforced=false
        }
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the app navigation")
    override fun onBackPressed() {
        if(isDashboardPage) showExitDialog() else currentBack()
    }

    private fun showExitDialog() {
        val exitTitle=TextView(this).apply {
            text="خروج از دفتر کار من"
            textSize=20f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(ink)
            gravity=Gravity.RIGHT
            setPadding(dp(24),dp(20),dp(24),dp(8))
        }
        val dialog=AlertDialog.Builder(this)
            .setCustomTitle(exitTitle)
            .setMessage("برای خروج، یکی از روش‌های زیر را انتخاب کنید.")
            .setPositiveButton("پشتیبان‌گیری و خروج",null)
            .setNegativeButton("خروج",null)
            .setNeutralButton("ادامه کار",null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(rounded(surface,20))
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(muted)
            dialog.getButton(-1).setTextColor(teal)
            dialog.getButton(-2).setTextColor(red)
            dialog.getButton(-3).setTextColor(muted)
            dialog.getButton(-1).setOnClickListener {
                if(saveSingleBackup()) { toast("پشتیبان ذخیره و به‌روزرسانی شد"); dialog.dismiss(); finish() }
                else toast("پشتیبان‌گیری انجام نشد؛ برنامه باز می‌ماند")
            }
            dialog.getButton(-2).setOnClickListener { dialog.dismiss(); finish() }
        }
        dialog.show()
    }

    private fun authenticate() {
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object: BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { super.onAuthenticationSucceeded(result); showHome() }
            override fun onAuthenticationError(code:Int, message:CharSequence) { super.onAuthenticationError(code,message); if(code==BiometricPrompt.ERROR_NEGATIVE_BUTTON || code==BiometricPrompt.ERROR_USER_CANCELED) finish() else toast("ورود با اثر انگشت انجام نشد: $message") }
            override fun onAuthenticationFailed() { super.onAuthenticationFailed(); toast("اثر انگشت شناسایی نشد") }
        })
        val info=BiometricPrompt.PromptInfo.Builder().setTitle("قفل دفتر کارکرد من").setSubtitle("برای ورود، اثر انگشت یا قفل دستگاه را تأیید کنید").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG.or(BiometricManager.Authenticators.DEVICE_CREDENTIAL)).build()
        prompt.authenticate(info)
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun label(t:String,size:Float=16f):TextView = TextView(this).apply {
        text=t; textSize=size
        setTextColor(when {
            t.contains("مانده") -> balanceColor
            t.contains("دریافتی") || t.contains("پرداخت") -> red
            t.contains("کارکرد") || t.contains("دستمزد") || t.contains("مبلغ نهایی") -> workColor
            else -> ink
        })
        gravity=Gravity.RIGHT
        setPadding(dp(8),dp(7),dp(8),dp(7)); textDirection=View.TEXT_DIRECTION_RTL
    }
    private fun button(t:String, action:()->Unit):Button = Button(this).apply {
        text=t; isAllCaps=false; textSize=14f; textDirection=View.TEXT_DIRECTION_RTL
        setTextColor(Color.WHITE); background=rounded(blue,16); elevation=0f
        minHeight=dp(48); setPadding(dp(12),dp(5),dp(12),dp(5)); setOnClickListener { action() }
    }
    private fun smallActionButton(t:String, color:Int=blue, action:()->Unit):Button = Button(this).apply {
        text=t; isAllCaps=false; textSize=12f; setTextColor(Color.WHITE)
        minHeight=dp(34); minimumHeight=dp(34); setPadding(dp(8),0,dp(8),0)
        background=rounded(color,12); setOnClickListener { action() }
    }
    private fun card():LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12))
        background=rounded(surface,20); elevation=0f
    }
    private fun rounded(color:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius=dp(r).toFloat(); setStroke(dp(1),outline)
    }
    private fun bottomRounded(color:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        val radius=dp(r).toFloat()
        cornerRadii=floatArrayOf(0f,0f,0f,0f,radius,radius,radius,radius)
    }
    private fun isHoliday(work:Work)=work.note.trim()=="تعطیل"
    private fun addGap(target:LinearLayout=content, height:Int=8) {
        target.addView(View(this),LinearLayout.LayoutParams(1,dp(height)))
    }
    private fun sectionHeader(title:String, iconRes:Int):LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER_VERTICAL
        layoutDirection=View.LAYOUT_DIRECTION_LTR
        addView(ImageView(this@MainActivity).apply {
            setImageResource(iconRes)
            imageTintList=android.content.res.ColorStateList.valueOf(blue)
            scaleType=ImageView.ScaleType.FIT_CENTER
        },LinearLayout.LayoutParams(dp(14),dp(14)).apply { rightMargin=dp(6) })
        addView(View(this@MainActivity),LinearLayout.LayoutParams(0,1,1f))
        addView(label(title,12f).apply {
            setTypeface(null,android.graphics.Typeface.BOLD)
            gravity=Gravity.RIGHT
            textDirection=View.TEXT_DIRECTION_RTL
            includeFontPadding=false
            maxLines=1
            setPadding(0,0,0,0)
        })
    }
    private fun addDashedDivider(target:LinearLayout=content, top:Int=4, bottom:Int=4) {
        val divider=View(this).apply {
            background=android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius=0f
                setStroke(dp(1),outline,dp(4).toFloat(),dp(4).toFloat())
            }
        }
        target.addView(divider,LinearLayout.LayoutParams(-1,dp(1)).apply {
            topMargin=dp(top); bottomMargin=dp(bottom)
        })
    }
    private fun semanticAmountColor(title:String):Int = when {
        title.contains("کارکرد") -> workColor
        title.contains("دریافتی") || title.contains("پرداخت") -> red
        title.contains("مانده") || title.contains("باقی") -> balanceColor
        else -> ink
    }
    private fun statCard(title:String,value:String,accent:Int):LinearLayout = card().apply {
        setPadding(dp(9),dp(9),dp(9),dp(9))
        addView(label(title,11f).apply { setTextColor(muted) })
        addView(label(value,15f).apply { setTextColor(semanticAmountColor(title)); setTypeface(null,android.graphics.Typeface.BOLD) })
    }
    private fun actionTile(title:String, subtitle:String="", action:()->Unit):LinearLayout = card().apply {
        isClickable=true; isFocusable=true
        addView(label(title,16f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        if(subtitle.isNotBlank()) addView(label(subtitle,11f).apply { setTextColor(muted) })
        setOnClickListener { action() }
    }
    private fun base(title:String, onBack:()->Unit = { showHome() }) {
        currentBack=onBack
        isDashboardPage = title == "داشبورد"
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                if(isDarkTheme) intArrayOf(Color.rgb(16,17,22),Color.rgb(18,20,27),Color.rgb(20,23,31))
                else intArrayOf(Color.rgb(235,238,243),Color.rgb(231,235,241),Color.rgb(226,231,238))
            )
            setPadding(0,0,0,dp(2))
        }
        val header=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            layoutDirection=View.LAYOUT_DIRECTION_LTR
            setPadding(dp(18),dp(28),dp(18),dp(10))
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                if(isDarkTheme) intArrayOf(Color.rgb(23,25,43),Color.rgb(19,21,37),Color.rgb(16,18,31))
                else intArrayOf(Color.rgb(229,233,239),Color.rgb(225,230,237),Color.rgb(221,227,235))
            ).apply {
                cornerRadii=floatArrayOf(0f,0f,0f,0f,dp(34).toFloat(),dp(34).toFloat(),dp(34).toFloat(),dp(34).toFloat())
            }
        }
        val left=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            layoutDirection=View.LAYOUT_DIRECTION_LTR
        }
        fun headIcon(iconRes:Int, action:()->Unit)=FrameLayout(this).apply {
            background=rounded(surfaceAlt,15)
            val image=ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                imageTintList=android.content.res.ColorStateList.valueOf(blue)
                scaleType=ImageView.ScaleType.FIT_CENTER
            }
            addView(image,FrameLayout.LayoutParams(dp(21),dp(21),Gravity.CENTER))
            isClickable=true; isFocusable=true
            setOnClickListener { action() }
        }
        if(isDashboardPage) {
            left.addView(headIcon(R.drawable.ic_header_settings) { settingsScreen() },LinearLayout.LayoutParams(dp(42),dp(42)).apply { setMargins(dp(3),0,dp(5),0) })
            left.addView(headIcon(if(isDarkTheme) R.drawable.ic_theme_sun else R.drawable.ic_theme_moon) {
                prefs.edit().putBoolean("dark_mode",!isDarkTheme).apply()
                recreate()
            },LinearLayout.LayoutParams(dp(42),dp(42)).apply { setMargins(dp(3),0,dp(3),0) })
        } else {
            val backButton=FrameLayout(this).apply {
                background=android.graphics.drawable.GradientDrawable().apply {
                    shape=android.graphics.drawable.GradientDrawable.OVAL
                    setColor(if(isDarkTheme) Color.argb(42,145,175,215) else Color.argb(58,70,130,190))
                    setStroke(dp(1),if(isDarkTheme) Color.argb(85,190,210,240) else Color.argb(90,55,105,160))
                }
                val image=ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_back)
                    imageTintList=android.content.res.ColorStateList.valueOf(if(isDarkTheme) Color.rgb(105,180,245) else Color.rgb(35,105,175))
                    scaleType=ImageView.ScaleType.FIT_CENTER
                }
                addView(image,FrameLayout.LayoutParams(dp(23),dp(23),Gravity.CENTER))
                isClickable=true; isFocusable=true
                foreground=android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(if(isDarkTheme) Color.argb(45,255,255,255) else Color.argb(35,0,0,0)),
                    null,android.graphics.drawable.GradientDrawable().apply { shape=android.graphics.drawable.GradientDrawable.OVAL })
                setOnClickListener { currentBack() }
            }
            left.addView(backButton,LinearLayout.LayoutParams(dp(36),dp(36)).apply { setMargins(dp(2),0,dp(4),0) })
        }
        val titles=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT }
        titles.addView(TextView(this).apply {
            text=if(isDashboardPage) "دفتر کارکرد من" else title
            textSize=17f; setTextColor(ink); gravity=Gravity.RIGHT
            maxLines=2
            setTypeface(null,android.graphics.Typeface.BOLD); textDirection=View.TEXT_DIRECTION_RTL
        })
        titles.addView(TextView(this).apply {
            text="مدیریت هوشمند پروژه‌ها و حساب‌ها"
            textSize=11f; setTextColor(muted); gravity=Gravity.RIGHT
            setTypeface(null,android.graphics.Typeface.BOLD)
            setPadding(0,dp(1),0,0); textDirection=View.TEXT_DIRECTION_RTL
        })
        header.addView(left,LinearLayout.LayoutParams(-2,-2))
        header.addView(View(this),LinearLayout.LayoutParams(0,0,1f))
        header.addView(titles,LinearLayout.LayoutParams(-2,-2).apply { if(isDashboardPage) topMargin=dp(5) })
        root.addView(header,LinearLayout.LayoutParams(-1,dp(if(isDashboardPage) 112 else 94)))
        val scroll=ScrollView(this).apply { clipToPadding=false; isFillViewport=false }
        content=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14),dp(12),dp(14),dp(20))
        }
        scroll.addView(content)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val footer=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(dp(5),dp(5),dp(5),dp(5))
            background=rounded(surface,26)
            elevation=dp(10).toFloat()
        }
        fun navButton(iconRes:Int,caption:String,active:Boolean,action:()->Unit)=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            setPadding(dp(2),dp(1),dp(2),dp(1))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                scaleType=ImageView.ScaleType.FIT_CENTER
                imageTintList=android.content.res.ColorStateList.valueOf(if(active) blue else muted)
            },LinearLayout.LayoutParams(dp(21),dp(21)))
            addView(TextView(this@MainActivity).apply {
                text=caption; textSize=10f; gravity=Gravity.CENTER
                setTextColor(if(active) workColor else muted)
                setTypeface(null,if(active) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            })
            if(active) addView(View(this@MainActivity).apply {
                background=rounded(workColor,8)
            },LinearLayout.LayoutParams(dp(48),dp(2)).apply { topMargin=dp(2) })
            isClickable=true; isFocusable=true; setOnClickListener { action() }
        }
        listOf(
            navButton(R.drawable.nav_account,"حساب کاربری",false) { settingsScreen() },
            navButton(R.drawable.nav_projects,"پروژه‌ها",false) { projectsScreen() },
            navButton(R.drawable.nav_reports,"گزارش‌ها",false) { showPerformanceReports() },
            navButton(R.drawable.nav_home,"خانه",isDashboardPage) { showHome() }
        ).forEach { footer.addView(it,LinearLayout.LayoutParams(0,dp(42),1f)) }
        root.addView(footer,LinearLayout.LayoutParams(-1,dp(48)).apply {
            setMargins(dp(12),dp(2),dp(12),dp(36))
        })
        setContentView(root)
    }
    private fun row(vararg views:View) = rowIn(content,*views)
    private fun rowIn(target:LinearLayout,vararg views:View) {
        val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        views.forEach { r.addView(it,LinearLayout.LayoutParams(0,-2,1f).apply { setMargins(dp(3),0,dp(3),0) }) }
        target.addView(r)
    }
    private fun countryBanner(country:String, currencyLabel:String) : FrameLayout {
        val currencyWorkers=db.workers().filter { it.currency==currencyLabel }
        val earned=currencyWorkers.sumOf { db.total(it.id) }
        val received=currencyWorkers.sumOf { db.paid(it.id) }
        val balance=earned-received
        val card=FrameLayout(this).apply {
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                if(isDarkTheme) intArrayOf(Color.rgb(27,29,39),Color.rgb(24,26,35),Color.rgb(21,23,31))
                else intArrayOf(Color.WHITE,Color.rgb(250,251,253),Color.rgb(244,247,250))
            ).apply { cornerRadius=dp(25).toFloat(); setStroke(dp(1),outline) }
            clipToOutline=true
            elevation=dp(2).toFloat()
            isClickable=true; isFocusable=true
            setOnClickListener { projectsScreen(country) }
        }
        val top=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.RIGHT
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16),dp(10),dp(17),0)
        }
        val titleRow=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
            layoutDirection=View.LAYOUT_DIRECTION_RTL
        }
        titleRow.addView(label(country,21f).apply {
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(ink)
            setPadding(dp(2),0,dp(7),0)
        })
        titleRow.addView(TextView(this).apply {
            text=currencyLabel
            textSize=11f
            gravity=Gravity.CENTER
            setTextColor(if(isDarkTheme) Color.WHITE else blue)
            background=rounded(if(isDarkTheme) Color.rgb(37,58,88) else Color.rgb(230,239,249),18)
            setPadding(dp(11),dp(5),dp(11),dp(5))
        })
        top.addView(titleRow,LinearLayout.LayoutParams(-1,dp(36)))
        top.addView(label("خلاصه وضعیت حساب‌های $currencyLabel $country",12f).apply {
            setTextColor(muted); gravity=Gravity.RIGHT
            setPadding(dp(4),0,dp(4),0)
            maxLines=1; includeFontPadding=false
        },LinearLayout.LayoutParams(-1,dp(22)))
        card.addView(top,FrameLayout.LayoutParams(-1,dp(76),Gravity.TOP))

        val stats=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            background=if(isDarkTheme) android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(31,33,42),Color.rgb(25,27,35))
            ) else android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(250,251,252),Color.rgb(244,246,249))
            )
            setPadding(dp(7),dp(5),dp(7),dp(5))
        }
        fun metric(name:String,value:Long,color:Int)=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            val metricIcon=when(name) {
                "کارکرد" -> R.drawable.ic_work
                "دریافتی" -> R.drawable.ic_received
                else -> R.drawable.ic_balance
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(metricIcon)
                imageTintList=android.content.res.ColorStateList.valueOf(color)
                scaleType=ImageView.ScaleType.FIT_CENTER
            },LinearLayout.LayoutParams(dp(17),dp(17)))
            addView(label(name,11f).apply {
                gravity=Gravity.CENTER; setTextColor(muted)
                setPadding(dp(2),0,dp(2),0); maxLines=1
            },LinearLayout.LayoutParams(-1,dp(19)))
            addView(label(fmt(value),16f).apply {
                gravity=Gravity.CENTER; setTypeface(null,android.graphics.Typeface.BOLD)
                setTextColor(color); setSingleLine(true)
                setAutoSizeTextTypeUniformWithConfiguration(7,13,1,android.util.TypedValue.COMPLEX_UNIT_SP)
                setPadding(dp(1),0,dp(1),0)
            },LinearLayout.LayoutParams(-1,dp(27)))
        }
        stats.addView(metric("کارکرد",earned,workColor),LinearLayout.LayoutParams(0,-1,1f))
        stats.addView(View(this).apply { setBackgroundColor(outline) },LinearLayout.LayoutParams(dp(1),dp(58)))
        stats.addView(metric("دریافتی",received,red),LinearLayout.LayoutParams(0,-1,1f))
        stats.addView(View(this).apply { setBackgroundColor(outline) },LinearLayout.LayoutParams(dp(1),dp(58)))
        stats.addView(metric("مانده",balance,balanceColor),LinearLayout.LayoutParams(0,-1,1f))
        card.addView(stats,FrameLayout.LayoutParams(-1,dp(86),Gravity.BOTTOM))
        val countryDivider=View(this).apply {
            background=android.graphics.drawable.GradientDrawable().apply {
                setColor(outline); setSize(-1,dp(1))
            }
        }
        card.addView(countryDivider,FrameLayout.LayoutParams(-1,dp(1),Gravity.BOTTOM).apply { bottomMargin=dp(86) })
        val arrow=TextView(this).apply {
            text="›"; textSize=27f; gravity=Gravity.CENTER
            setTextColor(muted); background=rounded(surfaceAlt,50)
        }
        card.addView(arrow,FrameLayout.LayoutParams(dp(38),dp(38),Gravity.LEFT or Gravity.CENTER_VERTICAL).apply { leftMargin=dp(8) })
        return card
    }

    private fun dashboardTile(iconRes:Int,title:String,action:()->Unit):LinearLayout =
        LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(dp(4),dp(3),dp(4),dp(3))
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                if(isDarkTheme) intArrayOf(Color.rgb(34,37,48),Color.rgb(27,29,39))
                else intArrayOf(Color.WHITE,Color.rgb(246,248,251))
            ).apply { cornerRadius=dp(22).toFloat(); setStroke(dp(1),outline) }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                scaleType=ImageView.ScaleType.FIT_CENTER
                imageTintList=android.content.res.ColorStateList.valueOf(when {
                    title.contains("تنظیمات") -> workColor
                    title.contains("دریافتی") -> red
                    title.contains("گزارش") -> blue
                    else -> teal
                })
            },LinearLayout.LayoutParams(dp(19),dp(19)))
            addView(label(title,11f).apply {
                gravity=Gravity.CENTER
                includeFontPadding=false
                maxLines=1
                setTypeface(null,android.graphics.Typeface.BOLD)
            })
            isClickable=true; isFocusable=true; setOnClickListener { action() }
        }

    private fun homeGreetingBanner():FrameLayout {
        val banner=FrameLayout(this).apply {
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                if(isDarkTheme) intArrayOf(Color.rgb(34,39,77),Color.rgb(30,28,63),Color.rgb(38,35,72))
                else intArrayOf(Color.rgb(105,119,255),Color.rgb(157,169,255),Color.rgb(220,225,255))
            ).apply { cornerRadius=dp(25).toFloat(); setStroke(dp(1),if(isDarkTheme) Color.rgb(74,80,126) else Color.rgb(255,255,255)) }
            clipToOutline=true
        }
        // Full-bleed artwork: the supplied helmet image covers the entire greeting card.
        val art=ImageView(this).apply {
            setImageResource(R.drawable.home_helmet_banner)
            scaleType=ImageView.ScaleType.CENTER_CROP
            contentDescription="تصویر کلاه ایمنی و نقشه"
        }
        banner.addView(art,FrameLayout.LayoutParams(-1,-1))
        // A right-side translucent gradient keeps Persian text readable without splitting the image.
        val shade=View(this).apply {
            background=android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                if(isDarkTheme) intArrayOf(
                    Color.argb(8,13,18,42),
                    Color.argb(105,20,24,58),
                    Color.argb(218,18,21,49)
                ) else intArrayOf(
                    Color.argb(0,20,35,75),
                    Color.argb(105,35,52,112),
                    Color.argb(205,24,38,88)
                )
            )
        }
        banner.addView(shade,FrameLayout.LayoutParams(-1,-1))
        val details=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10),dp(9),dp(15),dp(9))
        }
        val now=Date()
        val greg=SimpleDateFormat("yyyy/MM/dd",Locale.US).format(now)
        val gparts=greg.split("/")
        val j=gregorianToJalali(gparts[0].toInt(),gparts[1].toInt(),gparts[2].toInt())
        val jal=String.format(Locale.US,"%04d/%02d/%02d",j.first,j.second,j.third)
        val day=SimpleDateFormat("EEEE",Locale("fa")).format(now)
        details.addView(label("امروز  •  $day",10.5f).apply {
            gravity=Gravity.RIGHT; setTextColor(if(isDarkTheme) Color.rgb(222,224,255) else Color.WHITE)
            setTypeface(null,android.graphics.Typeface.BOLD); includeFontPadding=false
        })
        details.addView(label("${persianDigits(jal)}   |   ${persianDigits(greg)}",10f).apply {
            gravity=Gravity.RIGHT; setTextColor(if(isDarkTheme) Color.rgb(205,207,235) else Color.WHITE)
            setTypeface(null,android.graphics.Typeface.BOLD); includeFontPadding=false
        })
        addGap(details,5)
        details.addView(label("سلام ${ownerName()} عزیز",18f).apply {
            gravity=Gravity.RIGHT; setTextColor(Color.WHITE)
            setTypeface(null,android.graphics.Typeface.BOLD); maxLines=1; includeFontPadding=false
        })
        details.addView(label("به دفتر کارکرد من خوش آمدید",11.5f).apply {
            gravity=Gravity.RIGHT; setTextColor(if(isDarkTheme) Color.rgb(229,230,250) else Color.WHITE)
            setTypeface(null,android.graphics.Typeface.BOLD); includeFontPadding=false
        })
        details.addView(label("مدیریت آسان کارکرد، دریافتی و پروژه‌ها",9.5f).apply {
            gravity=Gravity.RIGHT; setTextColor(if(isDarkTheme) Color.rgb(195,199,225) else Color.WHITE)
            includeFontPadding=false; maxLines=1
        })
        banner.addView(details,FrameLayout.LayoutParams(-1,-1))
        return banner
    }

    private fun showHome() {
        base("داشبورد")
        content.setPadding(dp(14),dp(10),dp(14),dp(26))
        content.addView(homeGreetingBanner(),LinearLayout.LayoutParams(-1,dp(88)))
        addGap(content,10)
        content.addView(countryBanner("عراق","دینار"),
            LinearLayout.LayoutParams(-1,dp(176)))
        addGap(content,8)
        content.addView(countryBanner("ایران","ریال"),
            LinearLayout.LayoutParams(-1,dp(176)))
        addGap(content,12)
        content.addView(sectionHeader("دسترسی سریع",R.drawable.ic_grid),LinearLayout.LayoutParams(-1,dp(27)))
        addGap(content,5)
        fun quickTile(iconRes:Int,title:String,action:()->Unit)=dashboardTile(iconRes,title,action)
        fun quickRow(items:List<LinearLayout>) {
            val r=LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER
                layoutDirection=View.LAYOUT_DIRECTION_LTR
            }
            items.forEach { item ->
                r.addView(item,LinearLayout.LayoutParams(0,dp(60),1f).apply {
                    setMargins(dp(3),0,dp(3),0)
                })
            }
            content.addView(r)
        }
        quickRow(listOf(
            quickTile(R.drawable.quick_projects,"پروژه‌ها") { projectsScreen() },
            quickTile(R.drawable.quick_people,"اشخاص") { showPeople() },
            quickTile(R.drawable.quick_reports,"گزارش عملکرد") { showPerformanceReports() }
        ))
        addGap(content,4)
        quickRow(listOf(
            quickTile(R.drawable.quick_people,"ثبت کارکرد گروهی") { batchWorkDialog() },
            quickTile(R.drawable.quick_payment,"دریافتی جدید") { paymentWorkerDialog() },
            quickTile(R.drawable.quick_settings,"تنظیمات") { settingsScreen() }
        ))
        addGap(content,12)
        addDashedDivider(content,2,6)
        content.addView(sectionHeader("پروژه‌های فعال",R.drawable.ic_briefcase),LinearLayout.LayoutParams(-1,dp(27)))
        val projects=db.projects().take(8)
        if(projects.isEmpty()) {
            content.addView(card().apply {
                addView(label("هنوز پروژه‌ای ثبت نشده است.",14f))
                addView(button("افزودن پروژه") { projectDialog() })
            })
        }
        projects.forEach { p ->
            val works=db.projectWorks(p.id).filterNot { isHoliday(it) }
            val earned=works.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong()+it.extraAmount }
            val paid=db.projectPaid(p.id)
            val tile=LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
                layoutDirection=View.LAYOUT_DIRECTION_RTL
                setPadding(dp(9),dp(7),dp(9),dp(7))
                background=android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                    if(p.accentColor!=0) intArrayOf(
                        Color.rgb((Color.red(surface)*0.78+Color.red(p.accentColor)*0.22).toInt(),
                            (Color.green(surface)*0.78+Color.green(p.accentColor)*0.22).toInt(),
                            (Color.blue(surface)*0.78+Color.blue(p.accentColor)*0.22).toInt()),
                        Color.rgb((Color.red(surface)*0.90+Color.red(p.accentColor)*0.10).toInt(),
                            (Color.green(surface)*0.90+Color.green(p.accentColor)*0.10).toInt(),
                            (Color.blue(surface)*0.90+Color.blue(p.accentColor)*0.10).toInt())
                    ) else if(isDarkTheme) intArrayOf(Color.rgb(29,33,48),Color.rgb(24,27,40))
                    else intArrayOf(Color.WHITE,Color.rgb(246,248,251))
                ).apply { cornerRadius=dp(24).toFloat(); setStroke(dp(1),outline) }
                val info=LinearLayout(this@MainActivity).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT }
                info.addView(label(p.name,15f).apply {
                    setTypeface(null,android.graphics.Typeface.BOLD)
                    setTextColor(ink); gravity=Gravity.RIGHT
                    maxLines=1; includeFontPadding=false
                })
                info.addView(label("${if(p.country=="عراق") "🇮🇶" else if(p.country=="ایران") "🇮🇷" else "🌐"} ${p.country} • ${p.currency}",11f).apply {
                    setTextColor(muted); gravity=Gravity.RIGHT
                    maxLines=1; includeFontPadding=false
                })
                addDashedDivider(info,1,3)
                val metrics=LinearLayout(this@MainActivity).apply { orientation=LinearLayout.HORIZONTAL; layoutDirection=View.LAYOUT_DIRECTION_RTL }
                val projectMetrics=listOf(Triple("کارکرد",earned,workColor),Triple("دریافتی",paid,red),Triple("مانده",earned-paid,balanceColor))
                projectMetrics.forEachIndexed { index,m ->
                    if(index>0) {
                        val dotted=View(this@MainActivity).apply {
                            background=android.graphics.drawable.GradientDrawable().apply {
                                setColor(Color.TRANSPARENT)
                                setStroke(dp(1),outline,dp(3).toFloat(),dp(3).toFloat())
                            }
                        }
                        metrics.addView(dotted,LinearLayout.LayoutParams(dp(1),dp(31)))
                    }
                    metrics.addView(LinearLayout(this@MainActivity).apply {
                        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
                        addView(label(m.first,9.5f).apply { gravity=Gravity.CENTER; setTextColor(muted); includeFontPadding=false; maxLines=1; setPadding(0,0,0,0) })
                        addView(label(fmt(m.second),12f).apply {
                            gravity=Gravity.CENTER; setTextColor(semanticAmountColor(m.first))
                            setTypeface(null,android.graphics.Typeface.BOLD); setSingleLine(true)
                            setAutoSizeTextTypeUniformWithConfiguration(7,12,1,android.util.TypedValue.COMPLEX_UNIT_SP)
                            setPadding(0,0,0,0); includeFontPadding=false
                        })
                    },LinearLayout.LayoutParams(0,-2,1f))
                }
                info.addView(metrics)
                addView(info,LinearLayout.LayoutParams(0,-2,1f))
                isClickable=true; isFocusable=true
                setOnClickListener { projectDetail(p) }
            }
            content.addView(tile,LinearLayout.LayoutParams(-1,dp(128))); addGap(content,6)
        }
        addGap(content,8)
        content.addView(card().apply {
            addView(label("پشتیبان‌گیری و بازیابی",16f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            addView(label("برای نگهداری امن اطلاعات، پشتیبان تهیه کن یا نسخه قبلی را بازیابی کن.",11f).apply { setTextColor(muted) })
            rowIn(this,
                smallActionButton("ذخیره پشتیبان",teal) { createBackup() },
                smallActionButton("بازیابی پشتیبان",blue) { restoreBackup() }
            )
        },LinearLayout.LayoutParams(-1,dp(128)))
    }
    private fun showPerformanceReports() {
        base("گزارش عملکرد")
        val people=db.workers()
        if(people.isEmpty()) {
            content.addView(card().apply { addView(label("برای تهیه گزارش ابتدا شخصی ثبت کنید.")) })
            return
        }
        people.forEach { w ->
            content.addView(card().apply {
                addView(label(w.fullName,16f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                rowIn(this,
                    statCard("کارکرد","${fmt(db.total(w.id))} ${w.currency}",workColor),
                    statCard("دریافتی","${fmt(db.paid(w.id))} ${w.currency}",red),
                    statCard("مانده","${fmt(db.total(w.id)-db.paid(w.id))} ${w.currency}",balanceColor))
                addView(button("عملکرد ماه/سال") { reportDialog(w) })
            })
            addGap()
        }
    }

    private fun showPeople() {
        base("اشخاص")
        val all=db.workers()
        content.addView(button("افزودن شخص") { workerDialog() })
        addGap()
        if(all.isEmpty()) {
            content.addView(card().apply { addView(label("هنوز شخصی ثبت نشده است.")) })
        }
        all.forEach { w ->
            val workList=db.works(w.id)
            val days=workList.filterNot { isHoliday(it) }.map { it.date }.distinct().size
            content.addView(card().apply {
                setPadding(dp(12),dp(9),dp(12),dp(9))
                val personHeader=LinearLayout(this@MainActivity).apply {
                    orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
                    addView(workerAvatar(w,dp(52)),LinearLayout.LayoutParams(dp(52),dp(52)).apply { leftMargin=dp(9) })
                    val info=LinearLayout(this@MainActivity).apply {
                        orientation=LinearLayout.VERTICAL
                        addView(label(w.fullName,16f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                        val details=listOf(if(w.age>0) "${w.age} سال" else "",w.phone).filter { it.isNotBlank() }.joinToString(" • ")
                        addView(label(if(details.isBlank()) "روزهای کاری: $days" else "$details  •  $days روز کاری",11f).apply { setTextColor(muted) })
                    }
                    addView(info,LinearLayout.LayoutParams(0,-2,1f))
                    addView(smallActionButton("ویرایش",blue) { workerDialog(w) },LinearLayout.LayoutParams(dp(72),dp(34)))
                }
                addView(personHeader,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(5) })
                val financialRows=listOf(
                    Triple("کارکرد","${fmt(db.total(w.id))} ${w.currency}",workColor),
                    Triple("دریافتی","${fmt(db.paid(w.id))} ${w.currency}",red),
                    Triple("مانده","${fmt(db.total(w.id)-db.paid(w.id))} ${w.currency}",balanceColor)
                )
                financialRows.forEachIndexed { index, item ->
                    val line=LinearLayout(this@MainActivity).apply {
                        orientation=LinearLayout.HORIZONTAL
                        gravity=Gravity.CENTER_VERTICAL
                        layoutDirection=View.LAYOUT_DIRECTION_RTL
                        setPadding(dp(5),dp(2),dp(5),dp(2))
                        addView(TextView(this@MainActivity).apply {
                            text=item.first
                            textSize=12f
                            setTextColor(muted)
                            gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
                        },LinearLayout.LayoutParams(dp(75),dp(28)))
                        addView(View(this@MainActivity),LinearLayout.LayoutParams(0,1,1f))
                        addView(TextView(this@MainActivity).apply {
                            text=item.second
                            textSize=14f
                            setTypeface(null,android.graphics.Typeface.BOLD)
                            setTextColor(item.third)
                            gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL
                            textDirection=View.TEXT_DIRECTION_LTR
                            maxLines=1
                        },LinearLayout.LayoutParams(-2,dp(28)))
                    }
                    addView(line,LinearLayout.LayoutParams(-1,dp(30)))
                    if(index<financialRows.lastIndex) {
                        val dotted=View(this@MainActivity).apply {
                            background=android.graphics.drawable.GradientDrawable().apply {
                                setColor(Color.TRANSPARENT)
                                setStroke(dp(1),outline,dp(3).toFloat(),dp(3).toFloat())
                            }
                        }
                        addView(dotted,LinearLayout.LayoutParams(-1,dp(1)).apply {
                            topMargin=dp(2); bottomMargin=dp(2)
                        })
                    }
                }
                addGap(this,5)
                val actions=LinearLayout(this@MainActivity).apply {
                    orientation=LinearLayout.HORIZONTAL
                    layoutDirection=View.LAYOUT_DIRECTION_RTL
                    gravity=Gravity.CENTER
                }
                actions.addView(button("ورود به پرونده  ←") { currentWorker=w; showWorker(w) },
                    LinearLayout.LayoutParams(0,dp(42),1f).apply { rightMargin=dp(4) })
                actions.addView(smallActionButton("حذف شخص",red) {
                    confirm("شخص و سوابق کارکرد و دریافتی وابسته به او حذف شوند؟ این کار قابل بازگشت نیست.") {
                        db.deleteWorker(w.id); showPeople()
                    }
                },LinearLayout.LayoutParams(0,dp(42),1f).apply { leftMargin=dp(4) })
                addView(actions,LinearLayout.LayoutParams(-1,dp(42)))
            })
            addDashedDivider(content,2,6)
        }
    }

    private fun currencySpinner(selected:String?=null):Spinner {
        val values=arrayOf("دینار","دلار","ریال")
        return Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,values); setSelection(values.indexOf(selected ?: currency()).coerceAtLeast(0)) }
    }
    private fun workerAvatar(w:Worker,size:Int):ImageView = ImageView(this).apply {
        background=android.graphics.drawable.GradientDrawable().apply {
            shape=android.graphics.drawable.GradientDrawable.OVAL
            setColor(if(isDarkTheme) Color.rgb(48,53,72) else Color.rgb(225,232,240))
            setStroke(dp(1),outline)
        }
        scaleType=ImageView.ScaleType.CENTER_CROP
        clipToOutline=true
        outlineProvider=android.view.ViewOutlineProvider.BACKGROUND
        if(w.photoUri.isNotBlank()) {
            try { setImageURI(Uri.parse(w.photoUri)) } catch(_:Exception) { setImageResource(R.drawable.nav_account) }
        } else {
            setImageResource(R.drawable.nav_account)
            imageTintList=android.content.res.ColorStateList.valueOf(blue)
            scaleType=ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(12),dp(12),dp(12),dp(12))
        }
        contentDescription=w.fullName
    }

    private fun workerDialog(existing:Worker?=null) {
        var photoUri=existing?.photoUri ?: ""
        val firstName=EditText(this).apply { hint="نام"; setText(existing?.name ?: ""); textDirection=View.TEXT_DIRECTION_RTL }
        val surname=EditText(this).apply { hint="نام خانوادگی"; setText(existing?.surname ?: ""); textDirection=View.TEXT_DIRECTION_RTL }
        val age=EditText(this).apply { hint="سن"; inputType=android.text.InputType.TYPE_CLASS_NUMBER; if((existing?.age ?: 0)>0) setText(existing!!.age.toString()) }
        val phone=EditText(this).apply { hint="شماره تلفن"; inputType=android.text.InputType.TYPE_CLASS_PHONE; setText(existing?.phone ?: ""); textDirection=View.TEXT_DIRECTION_LTR }
        val currency=currencySpinner(existing?.currency)
        val avatar=ImageView(this).apply {
            scaleType=ImageView.ScaleType.CENTER_CROP
            clipToOutline=true
            outlineProvider=android.view.ViewOutlineProvider.BACKGROUND
            background=android.graphics.drawable.GradientDrawable().apply { shape=android.graphics.drawable.GradientDrawable.OVAL; setColor(surfaceAlt); setStroke(dp(1),outline) }
            if(photoUri.isNotBlank()) try { setImageURI(Uri.parse(photoUri)) } catch(_:Exception) {}
            if(drawable==null) { setImageResource(R.drawable.nav_account); imageTintList=android.content.res.ColorStateList.valueOf(blue); scaleType=ImageView.ScaleType.CENTER_INSIDE; setPadding(dp(18),dp(18),dp(18),dp(18)) }
        }
        fun persistCropped(bitmap:Bitmap) {
            val file=File(filesDir,"worker_profile_${existing?.id ?: "new"}.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }
            photoUri=Uri.fromFile(file).toString()
            avatar.setImageBitmap(bitmap)
        }
        fun showCrop(bitmap:Bitmap) {
            val crop= CircularCropView(this,bitmap).apply {
                layoutParams=LinearLayout.LayoutParams(dp(280),dp(280))
            }
            val cropContainer=FrameLayout(this).apply {
                setPadding(dp(20),dp(12),dp(20),dp(12))
                addView(crop,FrameLayout.LayoutParams(dp(280),dp(280),Gravity.CENTER))
            }
            val cropDialog=AlertDialog.Builder(this)
                .setTitle("تنظیم عکس پروفایل")
                .setMessage("با کشیدن عکس و بزرگ‌نمایی، قسمت دلخواه را داخل دایره قرار بده.")
                .setView(cropContainer)
                .setPositiveButton("برش و ذخیره",null)
                .setNegativeButton("انصراف",null).create()
            cropDialog.setOnShowListener {
                cropDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    try { persistCropped(crop.cropped()); cropDialog.dismiss() }
                    catch(e:Exception) { toast("برش عکس انجام نشد") }
                }
            }
            cropDialog.show()
        }
        val gallery=smallActionButton("انتخاب از گالری",blue) {
            val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type="image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(intent,4107)
        }
        val camera=smallActionButton("گرفتن عکس با دوربین",blue) {
            try { startActivityForResult(Intent("android.media.action.IMAGE_CAPTURE"),4108) }
            catch(_:Exception) { toast("دوربین در دسترس نیست") }
        }
        val photoActions=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER
            addView(camera,LinearLayout.LayoutParams(0,dp(42),1f).apply { rightMargin=dp(5) })
            addView(gallery,LinearLayout.LayoutParams(0,dp(42),1f).apply { leftMargin=dp(5) })
        }
        workerPhotoPickerCallback={ bitmap -> if(bitmap!=null) showCrop(bitmap) }
        val form=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(8))
            addView(avatar,LinearLayout.LayoutParams(dp(88),dp(88)).apply { gravity=Gravity.CENTER; bottomMargin=dp(7) })
            addView(photoActions,LinearLayout.LayoutParams(-1,dp(42)).apply { bottomMargin=dp(10) })
            addView(firstName); addView(surname); addView(age); addView(phone)
            addView(label("واحد پول حساب",12f).apply { setTextColor(muted) })
            addView(currency,LinearLayout.LayoutParams(-1,dp(48)))
        }
        val scroll=ScrollView(this).apply { addView(form) }
        val dialog=AlertDialog.Builder(this)
            .setTitle(if(existing==null) "افزودن شخص" else "ویرایش مشخصات شخص")
            .setView(scroll).setPositiveButton(if(existing==null) "ثبت شخص" else "ذخیره تغییرات",null)
            .setNegativeButton("انصراف",null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n=firstName.text.toString().trim()
                val sn=surname.text.toString().trim()
                val a=age.text.toString().toIntOrNull() ?: 0
                if(n.isBlank()) { firstName.error="نام را وارد کنید"; return@setOnClickListener }
                if(a<0 || a>120) { age.error="سن معتبر وارد کنید"; return@setOnClickListener }
                if(existing==null) db.addWorker(n,currency.selectedItem.toString(),sn,a,phone.text.toString(),photoUri)
                else db.updateWorker(existing.id,n,currency.selectedItem.toString(),sn,a,phone.text.toString(),photoUri)
                dialog.dismiss(); showPeople()
            }
        }
        dialog.show()
    }

    private fun showWorker(w:Worker, showPayments:Boolean=false) {
        base("پرونده ${w.fullName}") { showPeople() }
        val works=db.works(w.id); val days=works.filterNot { isHoliday(it) }.map { it.date }.distinct().size
        content.addView(card().apply {
            val profileHead=LinearLayout(this@MainActivity).apply {
                orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
                addView(workerAvatar(w,dp(64)),LinearLayout.LayoutParams(dp(64),dp(64)).apply { leftMargin=dp(10) })
                val profileText=LinearLayout(this@MainActivity).apply {
                    orientation=LinearLayout.VERTICAL
                    addView(label(w.fullName,18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                    if(w.age>0 || w.phone.isNotBlank()) addView(LinearLayout(this@MainActivity).apply {
                        orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
                        layoutDirection=View.LAYOUT_DIRECTION_RTL
                        if(w.age>0) addView(label("${w.age} سال",12f).apply { setTextColor(muted); gravity=Gravity.CENTER_VERTICAL })
                        if(w.phone.isNotBlank()) {
                            val phoneInfo=LinearLayout(this@MainActivity).apply {
                                orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_LTR
                                val phoneIcon=ImageView(this@MainActivity).apply {
                                    setImageResource(R.drawable.ic_phone_minimal)
                                    imageTintList=android.content.res.ColorStateList.valueOf(muted)
                                }
                                addView(phoneIcon,LinearLayout.LayoutParams(dp(16),dp(16)).apply { rightMargin=dp(5) })
                                addView(label(w.phone,12f).apply { setTextColor(muted); textDirection=View.TEXT_DIRECTION_LTR; gravity=Gravity.CENTER_VERTICAL })
                                setOnClickListener {
                                    try { startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:${w.phone}"))) } catch(_:Exception) { toast("امکان شماره‌گیری وجود ندارد") }
                                }
                            }
                            addView(phoneInfo,LinearLayout.LayoutParams(-2,-2).apply { leftMargin=dp(8) })
                        }
                    })
                }
                addView(profileText,LinearLayout.LayoutParams(0,-2,1f))
                addView(smallActionButton("ویرایش",blue) { workerDialog(w) },LinearLayout.LayoutParams(dp(76),dp(36)))
            }
            addView(profileHead)
            addView(label("خلاصه حساب شخص",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            val earned=db.total(w.id)
            val received=db.paid(w.id)
            val balance=earned-received
            val summary=LinearLayout(this@MainActivity).apply {
                orientation=LinearLayout.VERTICAL
                background=rounded(surfaceAlt,15)
                setPadding(dp(14),dp(7),dp(14),dp(7))
            }
            fun summaryLine(caption:String,amount:String,color:Int) {
                val line=LinearLayout(this@MainActivity).apply {
                    orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
                    layoutDirection=View.LAYOUT_DIRECTION_LTR
                    addView(label(amount,15f).apply {
                        gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL
                        textDirection=View.TEXT_DIRECTION_LTR
                        setTextColor(color); setTypeface(null,android.graphics.Typeface.BOLD)
                    },LinearLayout.LayoutParams(0,dp(42),1f))
                    addView(label(caption,13f).apply {
                        gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
                        setTextColor(ink); setTypeface(null,android.graphics.Typeface.BOLD)
                    },LinearLayout.LayoutParams(0,dp(42),1f))
                }
                summary.addView(line)
            }
            fun dottedSeparator() {
                val line=View(this@MainActivity).apply {
                    layoutParams=LinearLayout.LayoutParams(-1,dp(1))
                    background=android.graphics.drawable.GradientDrawable().apply {
                        setColor(Color.TRANSPARENT)
                        setStroke(dp(1),outline,dp(3).toFloat(),dp(3).toFloat())
                    }
                }
                summary.addView(line)
            }
            summaryLine("کارکرد","${fmt(earned)} ${w.currency}",ink)
            dottedSeparator()
            summaryLine("دریافتی","${fmt(received)} ${w.currency}",ink)
            dottedSeparator()
            summaryLine("مانده","${if(balance<0) "-" else ""}${fmt(kotlin.math.abs(balance))} ${w.currency}",
                if(balance<0) red else balanceColor)
            addView(summary,LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(10); bottomMargin=dp(5) })
            addView(label("روزهای کاری: $days",12f).apply { setTextColor(muted) })
        })
        addGap()
        row(actionTile("ثبت کارکرد","افزودن روز کاری") { workDialog(listOf(w.id)) },actionTile("ثبت دریافتی","ثبت پرداخت") { paymentDialog(w) })
        addGap()
        addGap(content)
        row(actionTile("عملکرد ماه/سال","تعداد روز، اضافه‌کاری و مبالغ") { reportDialog(w) },actionTile("خروجی PDF","خلاصه حساب") { exportPdf(w) })
        addGap()
        val tabs=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER
            background=rounded(surface,16); setPadding(dp(4),dp(4),dp(4),dp(4))
        }
        val workTab=Button(this).apply {
            text="ریزکارکردها"; isAllCaps=false; textSize=13f; minHeight=dp(38); minimumHeight=dp(38)
            setTextColor(if(isDarkTheme) Color.WHITE else ink); background=rounded(if(!showPayments) headerPurple else Color.TRANSPARENT,12)
            setOnClickListener { showWorker(w,false) }
        }
        val paymentTab=Button(this).apply {
            text="دریافتی‌ها"; isAllCaps=false; textSize=13f; minHeight=dp(38); minimumHeight=dp(38)
            setTextColor(Color.WHITE); background=rounded(if(showPayments) headerPurple else Color.TRANSPARENT,12)
            setOnClickListener { showWorker(w,true) }
        }
        tabs.addView(workTab,LinearLayout.LayoutParams(0,dp(42),1f))
        tabs.addView(paymentTab,LinearLayout.LayoutParams(0,dp(42),1f))
        content.addView(tabs); addGap()
        if(!showPayments) {
            if(works.isEmpty()) content.addView(card().apply { addView(label("هنوز ریزکارکردی ثبت نشده است.",13f).apply { setTextColor(muted) }) })
            works.forEach { item ->
                val c=card(); c.addView(label(dateLabel(item.date),15f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                if(isHoliday(item)) {
                    c.addView(label("تعطیل",15f).apply { setTextColor(Color.rgb(255,75,85)); setTypeface(null,android.graphics.Typeface.BOLD) })
                } else {
                    c.addView(label("پروژه: ${db.projectName(item.projectId)}",12f).apply { setTextColor(green) })
                    c.addView(label("دستمزد ${fmt(item.wage)} ${w.currency}  •  اضافه‌کاری ${item.overtime} ساعت").apply { setTextColor(workColor) })
                    c.addView(label("شروع ${item.start}   |   پایان ${item.end}   |   مبلغ نهایی ${fmt(item.wage+(item.wage*item.overtime/8.0).toLong()+item.extraAmount)} ${w.currency}").apply { setTextColor(workColor) })
                    if(item.note.isNotBlank()) c.addView(label(item.note,13f).apply { setTextColor(muted) })
                }
                val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
                actions.addView(smallActionButton("ویرایش",teal) { editWorkDialog(item,w) },
                    LinearLayout.LayoutParams(0,dp(36),1f).apply { setMargins(dp(3),0,dp(3),0) })
                actions.addView(smallActionButton("حذف",red) { confirm("این رکورد حذف شود؟") { db.deleteWork(item.id); showWorker(w,false) } },
                    LinearLayout.LayoutParams(0,dp(36),1f).apply { setMargins(dp(3),0,dp(3),0) })
                c.addView(actions); content.addView(c); addGap()
            }
        } else {
            val payments=db.payments(w.id)
            if(payments.isEmpty()) content.addView(card().apply { addView(label("هنوز دریافتی ثبت نشده است.",13f).apply { setTextColor(muted) }) })
            payments.forEach { p -> content.addView(card().apply {
                addView(label(dateLabel(p.date),15f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                addView(label("مبلغ دریافتی: ${fmt(p.amount)} ${w.currency}").apply { setTextColor(red) })
                if(p.projectId!=null) addView(label("پروژه: ${db.projectName(p.projectId)}",12f).apply { setTextColor(green) })
                if(p.note.isNotBlank()) addView(label(p.note,13f).apply { setTextColor(muted) })
                addView(smallActionButton("حذف دریافتی",red) { confirm("این دریافتی حذف شود؟") { db.deletePayment(p.id); showWorker(w,true) } })
            }); addGap() }
        }
    }

    private fun projectsScreen(countryFilter:String?=null) {
        base("پروژه‌ها") { settingsScreen() }
        content.addView(button("افزودن پروژه") { projectDialog() })
        addGap()
        val all=db.projects().filter { countryFilter==null || it.country==countryFilter }
        if(countryFilter!=null) content.addView(label("پروژه‌های $countryFilter",14f).apply { setTextColor(muted) })
        if(all.isEmpty()) content.addView(card().apply { addView(label("هنوز پروژه‌ای ثبت نشده است.")) })
        all.forEach { p ->
            val works=db.projectWorks(p.id)
            val workDays=works.filterNot { isHoliday(it) }.map { it.date }.distinct().size
            val total=works.filterNot { isHoliday(it) }.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong()+it.extraAmount }
            val people=works.map { it.workerId }.distinct().size
            content.addView(card().apply {
                addView(label(p.name,18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                addView(label("${p.country} • ${p.currency}",12f).apply { setTextColor(muted) })
                rowIn(this,statCard("روز کاری",workDays.toString(),green),statCard("اشخاص",people.toString(),teal),statCard("جمع کارکرد", "${fmt(total)} ${p.currency}",green))
                addGap(this,6)
                addView(button("مشاهده گزارش پروژه  ←") { projectDetail(p) })
                addGap(this,12)
                rowIn(this,
                    smallActionButton("ویرایش نام",blue) { projectDialog(p) },
                    smallActionButton("حذف پروژه",red) { confirm("پروژه حذف شود؟ سوابق کارکرد حفظ و از پروژه جدا می‌شوند.") { db.deleteProject(p.id); projectsScreen() } })
            })
            addDashedDivider(content,2,6)
        }
    }
    private fun projectDialog(project:Project?=null) {
        val input=EditText(this).apply { hint="نام پروژه"; project?.let { setText(it.name) } }
        val locale=java.util.Locale("fa")
        val countries=java.util.Locale.getISOCountries().map { code ->
            val display=java.util.Locale("",code).getDisplayCountry(locale)
            display.ifBlank { code }
        }.distinct().sorted().toMutableList()
        listOf("عراق","ایران").forEach { if(!countries.contains(it)) countries.add(0,it) }
        val country=Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,countries)
            setSelection(countries.indexOf(project?.country ?: "عراق").coerceAtLeast(0))
        }
        val currencies=java.util.Currency.getAvailableCurrencies().map { it.currencyCode }.distinct().sorted().toMutableList()
        listOf("IQD","IRR","USD").forEach { if(!currencies.contains(it)) currencies.add(0,it) }
        val appLocale=Locale(prefs.getString("app_language","fa") ?: "fa")
        val currencyLabels=currencies.map { code ->
            try { "${Currency.getInstance(code).getDisplayName(appLocale)} ($code)" } catch(_:Exception) { code }
        }
        val currency=Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,currencyLabels)
            val legacy=when(project?.currency) { "دینار"->"IQD"; "ریال"->"IRR"; "دلار"->"USD"; else->project?.currency }
            setSelection(currencies.indexOf(legacy ?: "IQD").coerceAtLeast(0))
        }
        val palette=intArrayOf(0,Color.rgb(87,126,220),Color.rgb(122,91,190),Color.rgb(47,151,129),Color.rgb(205,139,55),Color.rgb(190,83,105))
        val colorNames=arrayOf("پیش‌فرض","آبی","بنفش","سبز","کهربایی","رز")
        var selectedColorIndex=palette.indexOf(project?.accentColor ?: 0).coerceAtLeast(0)
        val swatches=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; layoutDirection=View.LAYOUT_DIRECTION_LTR }
        val preview=TextView(this).apply {
            text="پیش‌نمایش بنر پروژه"
            gravity=Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setPadding(dp(14),dp(10),dp(14),dp(10))
            setTextColor(ink); textSize=14f
        }
        fun refreshColorPreview() {
            val c=palette[selectedColorIndex]
            preview.background=rounded(if(c==0) surfaceAlt else Color.rgb(
                (Color.red(surface)*0.68+Color.red(c)*0.32).toInt(),
                (Color.green(surface)*0.68+Color.green(c)*0.32).toInt(),
                (Color.blue(surface)*0.68+Color.blue(c)*0.32).toInt()),16)
            preview.text="پیش‌نمایش بنر پروژه • ${colorNames[selectedColorIndex]}"
        }
        palette.forEachIndexed { index,c ->
            val dot=View(this).apply {
                background=android.graphics.drawable.GradientDrawable().apply {
                    shape=android.graphics.drawable.GradientDrawable.OVAL
                    setColor(if(c==0) surfaceAlt else c)
                    setStroke(dp(if(index==selectedColorIndex) 3 else 1),if(index==selectedColorIndex) blue else outline)
                }
                isClickable=true
                setOnClickListener {
                    selectedColorIndex=index
                    for(i in 0 until swatches.childCount) {
                        val child=swatches.getChildAt(i)
                        child.background=android.graphics.drawable.GradientDrawable().apply {
                            shape=android.graphics.drawable.GradientDrawable.OVAL
                            setColor(if(palette[i]==0) surfaceAlt else palette[i])
                            setStroke(dp(if(i==selectedColorIndex) 3 else 1),if(i==selectedColorIndex) blue else outline)
                        }
                    }
                    refreshColorPreview()
                }
            }
            swatches.addView(dot,LinearLayout.LayoutParams(dp(30),dp(30)).apply { setMargins(dp(5),dp(7),dp(5),dp(7)) })
        }
        refreshColorPreview()
        country.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent:AdapterView<*>?) {}
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long) {
                val selectedName=countries[position]
                val lang=prefs.getString("app_language","fa") ?: "fa"
                val locale=Locale(lang)
                val iso=Locale.getISOCountries().firstOrNull { Locale("",it).getDisplayCountry(Locale("fa"))==selectedName }
                val code=try { if(iso!=null) Currency.getInstance(Locale("",iso)).currencyCode else null } catch(_:Exception) { null }
                if(code!=null) {
                    val idx=currencies.indexOf(code)
                    if(idx>=0) currency.setSelection(idx)
                }
            }
        }
        formDialog(if(project==null) "افزودن پروژه" else "ویرایش پروژه",
            listOf(input,label("انتخاب کشور",13f),country,label("انتخاب واحد پول",13f),currency,label("رنگ بنر پروژه",13f),swatches,preview)) {
            val name=input.text.toString().trim()
            if(name.isBlank()) { toast("نام پروژه را وارد کنید"); false }
            else try {
                val selectedCode=currencies[currency.selectedItemPosition]
                val selectedCurrency=when(selectedCode) { "IQD"->"دینار"; "IRR"->"ریال"; "USD"->"دلار"; else->selectedCode }
                val selectedColor=palette[selectedColorIndex]
                if(project==null) db.addProject(name,selectedCurrency,country.selectedItem.toString(),selectedColor)
                else db.renameProject(project.id,name,selectedCurrency,country.selectedItem.toString(),selectedColor)
                projectsScreen(); true
            } catch(_:Exception) { toast("این نام پروژه قبلاً ثبت شده است"); false }
        }
    }
    private fun projectDetail(project:Project) {
        base(project.name) { projectsScreen() }
        val works=db.projectWorks(project.id)
        val regular=works.filterNot { isHoliday(it) }
        val total=regular.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong()+it.extraAmount }
        val peopleIds=regular.map { it.workerId }.distinct()
        val paidByProject=db.projectPaid(project.id)
        val projectPayments=db.projectPayments(project.id)
        val extraExpenses=db.projectExpenses(project.id).sumOf { it.amount }
        val materialCosts=db.projectMaterials(project.id).sumOf { (it.quantity*it.unitPrice).toLong() }
        content.addView(card().apply {
            addView(label("خلاصه پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            rowIn(this,statCard("روز کاری",regular.map{it.date}.distinct().size.toString(),green),statCard("تعداد اشخاص",peopleIds.size.toString(),teal))
            val financeRows=listOf(
                Triple("جمع کارکرد","${fmt(total)} ${project.currency}",workColor),
                Triple("پرداخت‌های مرتبط","${fmt(paidByProject)} ${project.currency}",red)
            )
            financeRows.forEachIndexed { index,item ->
                val financeLine=LinearLayout(this@MainActivity).apply {
                    orientation=LinearLayout.HORIZONTAL
                    gravity=Gravity.CENTER_VERTICAL
                    layoutDirection=View.LAYOUT_DIRECTION_RTL
                    addView(TextView(this@MainActivity).apply {
                        text=item.first; textSize=12f; setTextColor(muted)
                        gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
                    },LinearLayout.LayoutParams(0,dp(32),1f))
                    addView(TextView(this@MainActivity).apply {
                        text=item.second; textSize=14f; setTypeface(null,android.graphics.Typeface.BOLD)
                        setTextColor(item.third); gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL
                        textDirection=View.TEXT_DIRECTION_LTR
                    },LinearLayout.LayoutParams(-2,dp(32)))
                }
                addView(financeLine,LinearLayout.LayoutParams(-1,dp(34)))
                if(index==0) {
                    val dotted=View(this@MainActivity).apply {
                        background=android.graphics.drawable.GradientDrawable().apply {
                            setColor(Color.TRANSPARENT)
                            setStroke(dp(1),outline,dp(3).toFloat(),dp(3).toFloat())
                        }
                    }
                    addView(dotted,LinearLayout.LayoutParams(-1,dp(1)).apply { topMargin=dp(2); bottomMargin=dp(2) })
                }
            }
            addView(label("هزینه‌های جانبی: ${fmt(extraExpenses)} ${project.currency}"))
            addView(label("هزینه مصالح و کالا: ${fmt(materialCosts)} ${project.currency}"))
            addView(label("مانده پس از پرداخت‌ها و هزینه‌ها: ${fmt(total+extraExpenses+materialCosts-paidByProject)} ${project.currency}",14f).apply { setTextColor(balanceColor) })
            addView(label("توجه: واحد پول دستمزدها مطابق پرونده هر شخص است؛ جمع کارکرد پروژه، جمع عددی مبالغ ثبت‌شده است.",11f).apply { setTextColor(muted) })
            addView(label("روزهای تعطیل: ${works.count{isHoliday(it)}}",12f).apply { setTextColor(red) })
        })
        addGap()
        addGap()
        content.addView(label("پرداخت‌های ثبت‌شده برای پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        if(projectPayments.isEmpty()) content.addView(label("هنوز پرداختی به این پروژه اختصاص داده نشده است.",13f).apply { setTextColor(muted) })
        projectPayments.forEach { payment ->
            val person=db.workers().firstOrNull{it.id==payment.workerId}?.name ?: "شخص حذف‌شده"
            content.addView(card().apply {
                addView(label("$person  •  ${dateLabel(payment.date)}",14f))
                addView(label("پرداخت: ${fmt(payment.amount)} ${project.currency}").apply { setTextColor(red) })
                if(payment.note.isNotBlank()) addView(label(payment.note,12f).apply { setTextColor(muted) })
            })
            addGap()
        }
        addGap()
        content.addView(label("هزینه‌های جانبی پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        content.addView(button("＋ ثبت هزینه خوراک، حمل‌ونقل یا سایر") { addProjectExpenseDialog(project) })
        val expenses=db.projectExpenses(project.id)
        expenses.forEach { e -> content.addView(card().apply { addView(label("${e.category} • ${dateLabel(e.date)}",14f)); addView(label("${fmt(e.amount)} ${project.currency}")); if(e.note.isNotBlank()) addView(label(e.note,12f).apply { setTextColor(muted) }) }); addGap() }
        if(expenses.isEmpty()) content.addView(label("هزینه جانبی ثبت نشده است.",12f).apply { setTextColor(muted) })
        addGap()
        content.addView(label("مصالح و کالاهای خریداری‌شده",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        content.addView(button("＋ ثبت خرید مصالح یا کالا") { addProjectMaterialDialog(project) })
        val materials=db.projectMaterials(project.id)
        materials.forEach { m -> content.addView(card().apply { addView(label("${m.name} • ${dateLabel(m.date)}",14f)); addView(label("مقدار: ${m.quantity} ${m.unit} × ${fmt(m.unitPrice)} ${project.currency}")); addView(label("جمع: ${fmt((m.quantity*m.unitPrice).toLong())} ${project.currency}")); if(m.note.isNotBlank()) addView(label(m.note,12f).apply { setTextColor(muted) }) }); addGap() }
        if(materials.isEmpty()) content.addView(label("خریدی ثبت نشده است.",12f).apply { setTextColor(muted) })
        addGap()
        content.addView(label("گزارش افراد در این پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        val workersById=db.workers().associateBy { it.id }
        peopleIds.forEach { workerId ->
            val person=workersById[workerId]
            val personWorks=regular.filter { it.workerId==workerId }
            val personPayments=projectPayments.filter { it.workerId==workerId }
            val earned=personWorks.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong()+it.extraAmount }
            val received=personPayments.sumOf { it.amount }
            val personName=person?.name ?: "شخص حذف‌شده"
            content.addView(card().apply {
                isClickable=true; isFocusable=true
                addView(label("$personName  ›",16f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                addView(label("${personWorks.map{it.date}.distinct().size} روز کاری  •  کارکرد ${fmt(earned)}  •  دریافتی ${fmt(received)}",12f).apply { setTextColor(muted) })
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("گزارش $personName در ${project.name}")
                        .setMessage("روزهای کاری: ${personWorks.map{it.date}.distinct().size}\nتعداد ثبت کارکرد: ${personWorks.size}\nجمع کارکرد: ${fmt(earned)} ${person?.currency ?: project.currency}\nدریافتی مرتبط با پروژه: ${fmt(received)} ${project.currency}\nمانده: ${fmt(earned-received)} ${project.currency}")
                        .setPositiveButton("بستن",null).show()
                }
            })
            addGap()
        }
        if(peopleIds.isEmpty()) content.addView(label("برای این پروژه هنوز کارکردی ثبت نشده است.",13f).apply { setTextColor(muted) })
        if(works.isEmpty()) content.addView(label("برای این پروژه هنوز کارکردی ثبت نشده است."))
    }

    private fun addProjectExpenseDialog(project:Project) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val category=AutoCompleteTextView(this).apply {
            hint="دسته هزینه (انتخاب یا عنوان جدید)"
            setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,db.catalog("project_expense_categories")+listOf("خوراک","حمل‌ونقل","سایر")))
            setText(db.catalog("project_expense_categories").firstOrNull() ?: "خوراک",false)
        }
        val amount=EditText(this).apply { hint="مبلغ (${project.currency})"; inputType=2 }
        val remember=CheckBox(this).apply { text="ذخیره این عنوان برای دفعات بعد"; isChecked=true }
        val note=EditText(this).apply { hint="توضیحات (اختیاری)" }
        formDialog("ثبت هزینه جانبی پروژه",listOf(date,category,remember,amount,note)) {
            val v=amount.text.toString().toLongOrNull()
            if(v==null || v<0 || date.text.isBlank()) { toast("تاریخ و مبلغ را بررسی کنید"); false }
            else { val cat=category.text.toString().trim(); if(cat.isBlank()) { toast("عنوان هزینه را وارد کنید"); false } else { if(remember.isChecked) db.saveCatalog("project_expense_categories",cat); db.addProjectExpense(project.id,toGregorian(date.text.toString()),cat,v,note.text.toString()); projectDetail(project); true } }
        }
    }
    private fun addProjectMaterialDialog(project:Project) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val name=AutoCompleteTextView(this).apply {
            hint="نام کالا یا مصالح (انتخاب یا نام جدید)"
            setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,db.catalog("project_material_names")))
        }
        val remember=CheckBox(this).apply { text="ذخیره نام مصالح برای دفعات بعد"; isChecked=true }
        val quantity=EditText(this).apply { hint="تعداد / مقدار"; inputType=8194 }
        val unit=EditText(this).apply { hint="واحد (عدد، کیلو، متر و...)" }
        val price=EditText(this).apply { hint="قیمت واحد (${project.currency})"; inputType=2 }
        val note=EditText(this).apply { hint="توضیحات (اختیاری)" }
        formDialog("ثبت خرید مصالح و کالا",listOf(date,name,remember,quantity,unit,price,note)) {
            val q=quantity.text.toString().replace(',','.').toDoubleOrNull(); val v=price.text.toString().toLongOrNull(); val n=name.text.toString().trim()
            if(date.text.isBlank() || n.isBlank() || q==null || q<=0 || v==null || v<0 || unit.text.isBlank()) { toast("اطلاعات خرید را بررسی کنید"); false }
            else { if(remember.isChecked) db.saveCatalog("project_material_names",n); db.addProjectMaterial(project.id,toGregorian(date.text.toString()),n,q,unit.text.toString().trim(),v,note.text.toString()); projectDetail(project); true }
        }
    }

    private fun settingsScreen() {
        base("تنظیمات برنامه")
        content.addView(button("مدیریت پروژه‌ها  ›") { projectsScreen() })
        addGap()
        val ownerNameInput=EditText(this).apply {
            hint="نام و نام خانوادگی صاحب برنامه"
            setText(ownerName())
            isSingleLine=true
            textDirection=View.TEXT_DIRECTION_RTL
            gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setTextColor(ink); setHintTextColor(muted)
            background=rounded(surfaceAlt,14)
            setPadding(dp(13),dp(10),dp(13),dp(10))
        }
        content.addView(card().apply {
            addView(label("پروفایل صاحب برنامه",15f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            addView(label("این نام در بنر خوشامدگویی صفحه اصلی نمایش داده می‌شود.",11f).apply { setTextColor(muted) })
            addView(ownerNameInput)
        })
        addGap()
        val themeSwitch=Switch(this).apply {
            text="حالت شب"
            isChecked=isDarkTheme
            setTextColor(ink)
            thumbTintList=android.content.res.ColorStateList.valueOf(if(isDarkTheme) blue else blue)
            trackTintList=android.content.res.ColorStateList.valueOf(if(isDarkTheme) Color.rgb(72,78,92) else Color.rgb(194,211,230))
        }
        themeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("dark_mode",checked).apply()
            recreate()
        }
        content.addView(card().apply {
            addView(label("پوسته برنامه",15f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            addView(label("انتخاب حالت روشن یا تاریک",11f).apply { setTextColor(muted) })
            addView(themeSwitch)
        })
        addGap()
        content.addView(label("واحد پول",18f))
        val currencies=arrayOf("دینار","دلار","ریال")
        val currencySpinner=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,currencies); setSelection(currencies.indexOf(currency()).coerceAtLeast(0)) }
        content.addView(currencySpinner)
        content.addView(label("زبان برنامه",18f))
        val languageOptions=arrayOf("فارسی","العربية","English")
        val languageCodes=arrayOf("fa","ar","en")
        val languageSpinner=Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,languageOptions)
            setSelection(languageCodes.indexOf(prefs.getString("app_language","fa")).coerceAtLeast(0))
        }
        content.addView(languageSpinner)
        content.addView(label("تقویم پیش‌فرض",18f))
        val calendars=arrayOf("میلادی","ایرانی (شمسی)")
        val calendarSpinner=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,calendars); setSelection(if(jalali())1 else 0) }
        content.addView(calendarSpinner)
        val lock=Switch(this).apply { text="فعال‌کردن قفل اثر انگشت / قفل دستگاه"; isChecked=prefs.getBoolean("biometric",false) }
        content.addView(lock)
        content.addView(button("ذخیره تنظیمات") {
            val newOwnerName=ownerNameInput.text.toString().trim()
            if(newOwnerName.isBlank()) { ownerNameInput.error="نام صاحب برنامه را وارد کنید"; return@button }
            prefs.edit().putString("owner_name",newOwnerName)
                .putString("currency",currencies[currencySpinner.selectedItemPosition])
                .putString("app_language",languageCodes[languageSpinner.selectedItemPosition])
                .putBoolean("jalali",calendarSpinner.selectedItemPosition==1)
                .putBoolean("biometric",lock.isChecked).apply()
            toast("تنظیمات ذخیره شد")
            if(lock.isChecked && !prefs.getBoolean("biometric_was_on",false)) {
                prefs.edit().putBoolean("biometric_was_on",true).apply()
                authenticate()
            } else showHome()
        })
        content.addView(label("تاریخ‌ها در پایگاه داده به‌صورت میلادی ذخیره می‌شوند؛ نمایش و ورود تاریخ با انتخاب تقویم تغییر می‌کند.",13f))
    }

    private fun reportDialog(w:Worker) {
        val modes=arrayOf("ماهانه","سالانه")
        val mode=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,modes) }
        val year=EditText(this).apply { hint="سال (مثلاً 2026)"; setText(if(jalali()) persianCalendar().get(Calendar.YEAR).toString() else Calendar.getInstance().get(Calendar.YEAR).toString()); inputType=2 }
        val month=EditText(this).apply {
            hint=if(jalali()) "ماه شمسی (۱ تا ۱۲)" else "ماه میلادی (۱ تا ۱۲)"
            setText(if(jalali()) (persianCalendar().get(Calendar.MONTH)+1).toString() else (Calendar.getInstance().get(Calendar.MONTH)+1).toString())
            inputType=2
        }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),dp(8)); addView(mode); addView(year); addView(month) }
        val d=AlertDialog.Builder(this).setTitle("گزارش حساب ${w.fullName}").setView(box).setPositiveButton("نمایش",null).setNegativeButton("لغو",null).create()
        d.setOnShowListener { d.window?.setBackgroundDrawable(rounded(surface,22)); d.getButton(-1).setTextColor(blue); d.getButton(-1).setOnClickListener {
            val y=year.text.toString().toIntOrNull()
            val m=month.text.toString().toIntOrNull()
            if(y==null || (mode.selectedItemPosition==0 && (m==null || m !in 1..12))) { toast("سال یا ماه را درست وارد کنید"); return@setOnClickListener }
            val selected=db.works(w.id).filter { matchesPeriod(it.date,y,m,mode.selectedItemPosition==0) }
            val selectedPayments=db.payments(w.id).filter { matchesPeriod(it.date,y,m,mode.selectedItemPosition==0) }
            val workEntries=selected.filterNot { isHoliday(it) }
            val holidays=selected.count { isHoliday(it) }
            val earned=workEntries.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong()+it.extraAmount }
            val received=selectedPayments.sumOf { it.amount }
            val workDays=workEntries.map { it.date }.distinct().size
            val overtimeHours=workEntries.sumOf { it.overtime }
            val period=if(mode.selectedItemPosition==0) "ماه $m سال $y" else "سال $y"
            val chart=object:View(this) {
                val values=if(mode.selectedItemPosition==0) (1..31).map { day ->
                    selected.filter { !isHoliday(it) && try { SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(it.date)!!.let { dt -> Calendar.getInstance().apply { time=dt }.get(Calendar.DAY_OF_MONTH)==day } } catch(_:Exception){false} }
                        .sumOf { it.wage+(it.wage*it.overtime/8.0).toLong()+it.extraAmount }
                } else (1..12).map { mo ->
                    selected.filter { !isHoliday(it) && try { val dt=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(it.date)!!; val cal=if(jalali()) persianCalendar().apply{time=dt} else Calendar.getInstance().apply{time=dt}; cal.get(Calendar.MONTH)+1==mo } catch(_:Exception){false} }
                        .sumOf { it.wage+(it.wage*it.overtime/8.0).toLong()+it.extraAmount }
                }
                override fun onDraw(canvas:android.graphics.Canvas) {
                    super.onDraw(canvas)
                    val maxValue=(values.maxOrNull() ?: 0L).coerceAtLeast(1L)
                    val gap=dp(3).toFloat(); val barW=(width-gap*(values.size+1))/values.size
                    values.forEachIndexed { idx,v ->
                        val h=(height*0.78f*(v.toFloat()/maxValue)).coerceAtLeast(if(v>0) dp(2).toFloat() else 0f)
                        val x=gap+idx*(barW+gap)
                        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=workColor; style=Paint.Style.FILL }
                        canvas.drawRoundRect(x,height-h,x+barW,height.toFloat(),dp(3).toFloat(),dp(3).toFloat(),paint)
                    }
                }
            }.apply { layoutParams=LinearLayout.LayoutParams(-1,dp(145)); background=rounded(surfaceAlt,14) }
            val reportBox=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),dp(8))
                addView(chart)
                addView(label("شخص: ${w.fullName}\nروز کاری: $workDays | تعطیل: $holidays\nاضافه‌کاری: ${"%.2f".format(Locale.US,overtimeHours)} ساعت\nکارکرد: ${fmt(earned)} ${w.currency}\nدریافتی: ${fmt(received)} ${w.currency}\nمانده: ${fmt(earned-received)} ${w.currency}",13f))
            }
            AlertDialog.Builder(this).setTitle("گزارش کار و حساب $period")
                .setView(reportBox).setPositiveButton("بستن",null).show()
            d.dismiss()
        } }
        d.show()
    }

    // Android ICU locale extension selects the Persian (Jalali) calendar without an extra library.
    private fun persianCalendar(): Calendar =
        Calendar.getInstance(Locale.forLanguageTag("fa-IR-u-ca-persian"))

    private fun matchesPeriod(iso:String, year:Int, month:Int?, monthly:Boolean):Boolean {
        return try {
            val c=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)!!
            if(jalali()) {
                val pc=persianCalendar().apply { time=c }
                pc.get(Calendar.YEAR)==year && (!monthly || pc.get(Calendar.MONTH)+1==month)
            } else {
                val cal=Calendar.getInstance().apply { time=c }
                cal.get(Calendar.YEAR)==year && (!monthly || cal.get(Calendar.MONTH)+1==month)
            }
        } catch(_:Exception){false}
    }

    private fun dateHint()=if(jalali()) "تاریخ شمسی YYYY-MM-DD" else "تاریخ میلادی YYYY-MM-DD"
    private fun todayForInput():String = if(jalali()) dateForInput(today()) else today()
    private fun dateForInput(iso:String):String {
        val raw=if(!jalali()) iso.replace('-','/') else try {
            val dt=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)!!
            val pc=persianCalendar().apply { time=dt }
            String.format(Locale.US,"%04d/%02d/%02d",pc.get(Calendar.YEAR),pc.get(Calendar.MONTH)+1,pc.get(Calendar.DAY_OF_MONTH))
        } catch(_:Exception){iso.replace('-','/')}
        return raw.map { if(it in '0'..'9') ('۰'.code + (it-'0')).toChar() else it }.joinToString("")
    }
    private fun toGregorian(value:String):String {
        val ascii=value.map { ch -> when(ch) { in '۰'..'۹' -> ('0'.code + (ch-'۰')).toChar(); in '٠'..'٩' -> ('0'.code + (ch-'٠')).toChar(); else -> ch } }.joinToString("").replace('/','-')
        return try {
            val p=ascii.split("-"); require(p.size==3)
            if(!jalali()) String.format(Locale.US,"%04d-%02d-%02d",p[0].toInt(),p[1].toInt(),p[2].toInt()) else {
                val pc=persianCalendar().apply { clear(); set(Calendar.YEAR,p[0].toInt()); set(Calendar.MONTH,p[1].toInt()-1); set(Calendar.DAY_OF_MONTH,p[2].toInt()) }
                SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(pc.timeInMillis))
            }
        } catch(_:Exception){ascii}
    }
    private fun gregorianToJalali(gy:Int,gm:Int,gd:Int):Triple<Int,Int,Int> {
        val monthDays=intArrayOf(0,31,59,90,120,151,181,212,243,273,304,334)
        val gy2=if(gm>2) gy+1 else gy
        var days=355666+365*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+monthDays[gm-1]
        var jy=-1595+33*(days/12053)
        days%=12053
        jy+=4*(days/1461)
        days%=1461
        if(days>365) { jy+=(days-1)/365; days=(days-1)%365 }
        val jm=if(days<186) 1+days/31 else 7+(days-186)/30
        val jd=1+if(days<186) days%31 else (days-186)%30
        return Triple(jy,jm,jd)
    }
    private fun persianDigits(value:String)=value.map { if(it in '0'..'9') ('۰'.code+(it-'0')).toChar() else it }.joinToString("")
    private fun dateLabel(iso:String):String {
        return try {
            val parts=iso.split('-')
            val gy=parts[0].toInt(); val gm=parts[1].toInt(); val gd=parts[2].take(2).toInt()
            val date=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)!!
            val day=SimpleDateFormat("EEEE",Locale("fa")).format(date)
            val jal=gregorianToJalali(gy,gm,gd)
            val jalText=String.format(Locale.US,"%04d/%02d/%02d",jal.first,jal.second,jal.third)
            val gregText=String.format(Locale.US,"%04d/%02d/%02d",gy,gm,gd)
            "${persianDigits(jalText)} | ${persianDigits(gregText)} ($day)"
        } catch(_:Exception){iso}
    }

    private fun projectSpinner(selectedId:Long?=null):Spinner {
        val projects=db.projects()
        val names=listOf("بدون پروژه") + projects.map{it.name}
        return Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,names)
            setSelection(if(selectedId==null) 0 else (projects.indexOfFirst{it.id==selectedId}+1).coerceAtLeast(0))
        }
    }
    private fun selectedProject(spinner:Spinner):Long? {
        val projects=db.projects()
        return projects.getOrNull(spinner.selectedItemPosition-1)?.id
    }

    private fun batchWorkDialog() {
        val people=db.workers()
        if(people.isEmpty()) { toast("ابتدا شخص اضافه کنید"); return }
        val checks=people.map { w -> CheckBox(this).apply { text=w.fullName; tag=w.id } }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; checks.forEach { addView(it) } }
        val scroll=ScrollView(this).apply { addView(box) }
        val wrapper=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(scroll,LinearLayout.LayoutParams(-1,dp(180))) }
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val project=projectSpinner()
        val start=EditText(this).apply { hint="ساعت شروع، مثلاً 07:00" }
        val end=EditText(this).apply { hint="ساعت پایان، مثلاً 16:00" }
        val wage=EditText(this).apply { hint="دستمزد یک روز (۸ ساعت)"; inputType=2 }
        val overtimeLabel=label("اضافه‌کاری (به ساعت)",13f).apply {
            setTextColor(ink)
            setPadding(dp(2),dp(5),dp(2),dp(2))
        }
        val ot=EditText(this).apply { hint="مثلاً 2.5 (اختیاری)"; inputType=8194 }
        val dailyExtra=EditText(this).apply { hint="مبلغ اضافه همان روز (اختیاری)"; inputType=2 }
        val note=EditText(this).apply { hint="توضیحات (اختیاری)" }
        val holiday=CheckBox(this).apply { text="این روز تعطیل است"; setTextColor(Color.rgb(255,75,85)) }
        holiday.setOnCheckedChangeListener { _, checked ->
            listOf(start,end,wage,ot,dailyExtra,note).forEach { it.isEnabled=!checked; it.alpha=if(checked) 0.45f else 1f }
            if(checked) note.setText("تعطیل") else if(note.text.toString()=="تعطیل") note.setText("")
        }
        listOf(date,project,holiday,start,end,wage,overtimeLabel,ot,dailyExtra,note).forEach { wrapper.addView(it) }
        formDialog("ثبت یکسان برای چند شخص",listOf(wrapper)) {
            val ids=checks.filter { it.isChecked }.map { it.tag as Long }
            val amount=if(holiday.isChecked) 0L else wage.text.toString().toLongOrNull()
            val extra=if(holiday.isChecked) 0.0 else (ot.text.toString().toDoubleOrNull() ?: 0.0)
            val daily=if(holiday.isChecked) 0L else (dailyExtra.text.toString().toLongOrNull() ?: 0L)
            if(ids.isEmpty() || amount==null || extra<0 || daily<0 || date.text.isBlank()) { toast("اشخاص، تاریخ، دستمزد و اضافه‌کاری را بررسی کنید"); false }
            else { db.addWorks(ids,toGregorian(date.text.toString()),if(holiday.isChecked) "" else start.text.toString(),if(holiday.isChecked) "" else end.text.toString(),amount,extra,if(holiday.isChecked) "تعطیل" else note.text.toString(),selectedProject(project),daily); showHome(); true }
        }
    }
    private fun workDialog(ids:List<Long>) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val project=projectSpinner()
        val start=EditText(this).apply { hint="ساعت شروع" }; val end=EditText(this).apply { hint="ساعت پایان" }
        val wage=EditText(this).apply { hint="دستمزد روزانه (۸ ساعت)"; inputType=2 }
        val ot=EditText(this).apply { hint="اضافه‌کاری به ساعت (اختیاری)"; inputType=8194 }
        val extraAmount=EditText(this).apply { hint="مبلغ اضافه همان روز (اختیاری)"; inputType=2 }
        val note=EditText(this).apply { hint="توضیحات" }
        val holiday=CheckBox(this).apply { text="این روز تعطیل است"; setTextColor(Color.rgb(255,75,85)) }
        holiday.setOnCheckedChangeListener { _, checked ->
            listOf(start,end,wage,ot,extraAmount,note).forEach { it.isEnabled=!checked; it.alpha=if(checked) 0.45f else 1f }
            if(checked) note.setText("تعطیل") else if(note.text.toString()=="تعطیل") note.setText("")
        }
        formDialog("ثبت کارکرد",listOf(date,project,holiday,start,end,wage,ot,extraAmount,note)) {
            val amount=if(holiday.isChecked) 0L else wage.text.toString().toLongOrNull()
            val overtime=if(holiday.isChecked) 0.0 else (ot.text.toString().toDoubleOrNull() ?: 0.0)
            val dailyExtra=if(holiday.isChecked) 0L else (extraAmount.text.toString().toLongOrNull() ?: 0L)
            if(amount==null || date.text.isBlank() || overtime<0 || dailyExtra<0) { toast("تاریخ و مبالغ را بررسی کنید"); false }
            else { db.addWorks(ids,toGregorian(date.text.toString()),if(holiday.isChecked) "" else start.text.toString(),if(holiday.isChecked) "" else end.text.toString(),amount,overtime,if(holiday.isChecked) "تعطیل" else note.text.toString(),selectedProject(project),dailyExtra); currentWorker?.let { showWorker(it) } ?: showHome(); true }
        }
    }
    private fun editWorkDialog(w:Work, person:Worker) {
        val date=EditText(this).apply { hint=dateHint(); setText(dateForInput(w.date)) }
        val project=projectSpinner(w.projectId)
        val start=EditText(this).apply { setText(w.start); hint="شروع" }; val end=EditText(this).apply { setText(w.end); hint="پایان" }
        val wage=EditText(this).apply { setText(w.wage.toString()); inputType=2 }
        val ot=EditText(this).apply { setText(if(w.overtime==0.0) "" else w.overtime.toString()); inputType=8194 }
        val extraAmount=EditText(this).apply { setText(if(w.extraAmount==0L) "" else w.extraAmount.toString()); hint="مبلغ اضافه همان روز (اختیاری)"; inputType=2 }
        val note=EditText(this).apply { setText(if(isHoliday(w)) "" else w.note) }
        val holiday=CheckBox(this).apply { text="این روز تعطیل است"; setTextColor(Color.rgb(255,75,85)); isChecked=isHoliday(w) }
        holiday.setOnCheckedChangeListener { _, checked ->
            listOf(start,end,wage,ot,extraAmount,note).forEach { it.isEnabled=!checked; it.alpha=if(checked) 0.45f else 1f }
            if(checked) note.setText("تعطیل") else if(note.text.toString()=="تعطیل") note.setText("")
        }
        listOf(start,end,wage,ot,extraAmount,note).forEach { it.isEnabled=!holiday.isChecked; it.alpha=if(holiday.isChecked) 0.45f else 1f }
        formDialog("ویرایش کارکرد",listOf(date,project,holiday,start,end,wage,ot,extraAmount,note)) {
            val amount=if(holiday.isChecked) 0L else wage.text.toString().toLongOrNull()
            val extra=if(holiday.isChecked) 0.0 else (ot.text.toString().toDoubleOrNull() ?: 0.0)
            val dailyExtra=if(holiday.isChecked) 0L else (extraAmount.text.toString().toLongOrNull() ?: 0L)
            if(amount==null || extra<0 || dailyExtra<0 || date.text.isBlank()) { toast("اطلاعات را بررسی کنید"); false }
            else { db.updateWork(w.copy(date=toGregorian(date.text.toString()),start=if(holiday.isChecked) "" else start.text.toString(),end=if(holiday.isChecked) "" else end.text.toString(),wage=amount,overtime=extra,extraAmount=dailyExtra,note=if(holiday.isChecked) "تعطیل" else note.text.toString(),projectId=selectedProject(project))); showWorker(person); true }
        }
    }
    private fun paymentWorkerDialog() {
        val people=db.workers(); if(people.isEmpty()){toast("ابتدا شخص اضافه کنید");return}
        val names=people.map{it.name}.toTypedArray()
        AlertDialog.Builder(this).setTitle("انتخاب شخص").setItems(names){_,i->paymentDialog(people[i])}.setNegativeButton("لغو",null).show().window?.setBackgroundDrawable(rounded(surface,20))
    }
    private fun paymentDialog(w:Worker) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val amount=EditText(this).apply { hint="مبلغ دریافتی"; inputType=2 }
        val note=EditText(this).apply { hint="توضیحات" }
        val project=projectSpinner()
        formDialog("ثبت دریافتی برای ${w.fullName}",listOf(date,amount,project,note)) {
            val v=amount.text.toString().toLongOrNull()
            if(v==null || date.text.isBlank()) { toast("تاریخ و مبلغ را وارد کنید"); false } else { db.addPayment(w.id,toGregorian(date.text.toString()),v,note.text.toString(),selectedProject(project)); currentWorker?.let{showWorker(it)} ?: showHome(); true }
        }
    }
    private fun formDialog(title:String, views:List<View>, save:()->Boolean) {
        views.forEach { v ->
            if(v is EditText) {
                v.setPadding(dp(13),dp(11),dp(13),dp(11)); v.textSize=15f
                v.setTextColor(ink); v.setHintTextColor(muted); v.background=rounded(surfaceAlt,14)
                v.textDirection=View.TEXT_DIRECTION_RTL
            }
            if(v is Spinner) { v.background=rounded(surfaceAlt,14); v.setPadding(dp(8),dp(5),dp(8),dp(5)) }
        }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(4)); views.forEach { v -> addView(v,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(7) }) } }
        val scroll=ScrollView(this).apply { addView(box) }
        val d=AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("ذخیره",null).setNegativeButton("لغو",null).create()
        d.setOnShowListener { d.window?.setBackgroundDrawable(rounded(surface,22)); d.getButton(-1).setTextColor(blue); d.getButton(-2).setTextColor(Color.GRAY); d.getButton(-1).setOnClickListener { if(save()) d.dismiss() } }
        d.show()
    }
    private fun confirm(message:String, yes:()->Unit) { val d=AlertDialog.Builder(this).setMessage(message).setPositiveButton("تأیید"){_,_->yes()}.setNegativeButton("لغو",null).create(); d.setOnShowListener { d.window?.setBackgroundDrawable(rounded(surface,22)); d.getButton(-1).setTextColor(blue) }; d.show() }
    private fun exportPdf(w:Worker) {
        try {
            val pdf=PdfDocument()
            val works=db.works(w.id)
            val total=db.total(w.id); val received=db.paid(w.id); val balance=total-received
            val inkPdf=Color.rgb(34,42,58); val purple=Color.rgb(117,83,190)
            val redPdf=Color.rgb(205,66,76); val greenPdf=Color.rgb(45,139,91)
            var pageNo=1
            var page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create())
            var y=0f
            fun drawHeader(c:android.graphics.Canvas) {
                val bg=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=inkPdf }
                c.drawRoundRect(24f,24f,571f,142f,22f,22f,bg)
                val title=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE; textSize=25f; typeface=Typeface.create("sans-serif",Typeface.BOLD); textAlign=Paint.Align.RIGHT }
                c.drawText("دفتر کارکرد من",548f,66f,title)
                title.textSize=17f; title.typeface=Typeface.DEFAULT
                c.drawText("گزارش حساب: ${w.fullName}",548f,101f,title)
                y=172f
                val values=listOf(Triple("کارکرد",total,purple),Triple("دریافتی",received,redPdf),Triple("مانده",balance,greenPdf))
                values.forEachIndexed { idx,v ->
                    val left=24f+idx*184f
                    val card=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(244,246,250) }
                    c.drawRoundRect(left,y,left+176f,y+82f,14f,14f,card)
                    val label=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=inkPdf; textSize=14f; textAlign=Paint.Align.RIGHT }
                    c.drawText(v.first,left+162f,y+28f,label)
                    label.color=v.third; label.textSize=17f; label.typeface=Typeface.DEFAULT_BOLD
                    c.drawText("${fmt(v.second)} ${w.currency}",left+162f,y+59f,label)
                }
                y+=112f
                val section=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=inkPdf; textSize=17f; typeface=Typeface.DEFAULT_BOLD; textAlign=Paint.Align.RIGHT }
                c.drawText("ریز کارکرد روزانه",548f,y,section); y+=18f
            }
            fun startNewPage() {
                pdf.finishPage(page); pageNo++
                page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create())
                y=40f
            }
            fun row(text:String, color:Int=inkPdf) {
                if(y>790f) startNewPage()
                val c=page.canvas
                val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color=Color.rgb(225,229,236); strokeWidth=1f; pathEffect=android.graphics.DashPathEffect(floatArrayOf(4f,4f),0f) }
                c.drawLine(40f,y+10f,555f,y+10f,line)
                val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color=color; textSize=12f; textAlign=Paint.Align.RIGHT }
                c.drawText(text,548f,y,p); y+=27f
            }
            drawHeader(page.canvas)
            works.forEach { item ->
                val dayTotal=if(isHoliday(item)) 0L else item.wage+(item.wage*item.overtime/8.0).toLong()+item.extraAmount
                row(if(isHoliday(item)) "${dateLabel(item.date)}  •  تعطیل" else
                    "${dateLabel(item.date)}  |  دستمزد ${fmt(item.wage)}  |  اضافه‌کاری ${item.overtime} ساعت  |  مبلغ اضافه ${fmt(item.extraAmount)}  |  جمع ${fmt(dayTotal)}")
            }
            if(y>720f) startNewPage()
            y+=16f
            val ptitle=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=inkPdf; textSize=17f; typeface=Typeface.DEFAULT_BOLD; textAlign=Paint.Align.RIGHT }
            page.canvas.drawText("دریافتی‌ها",548f,y,ptitle); y+=24f
            db.payments(w.id).forEach { row("${dateLabel(it.date)}  |  ${fmt(it.amount)} ${w.currency}  |  ${it.note}") }
            pdf.finishPage(page)
            val name="Daftar-${w.fullName}-${System.currentTimeMillis()}.pdf"
            val values=android.content.ContentValues().apply { put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name); put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/pdf"); put(android.provider.MediaStore.Downloads.RELATIVE_PATH,android.os.Environment.DIRECTORY_DOWNLOADS) }
            val uri=contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values) ?: throw IOException("Cannot create PDF")
            contentResolver.openOutputStream(uri).use { pdf.writeTo(it!!) }; pdf.close(); toast("PDF گرافیکی در پوشه Downloads ذخیره شد")
        } catch(e:Exception){toast("ساخت PDF ناموفق بود: ${e.message}")}
    }
    private fun createBackup(){
        if(saveSingleBackup()) toast("پشتیبان به‌روزرسانی شد؛ نسخه قبلی جایگزین شد")
        else toast("تهیه پشتیبان ناموفق بود")
    }

    // Keep exactly one rolling backup file; each run overwrites the previous copy.
    private fun saveSingleBackup():Boolean {
        return try {
            db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use { c -> if(c.moveToFirst() && c.getInt(0)!=0) throw IOException("Database checkpoint is busy") }
            val databaseFile=getDatabasePath("daftar_native.db")
            if(!databaseFile.exists()) throw IOException("Database file not found")
            if(android.os.Build.VERSION.SDK_INT >= 29) {
                val resolver=contentResolver
                val collection=android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val name="daftar-karkard-backup.db"
                val relative=android.os.Environment.DIRECTORY_DOWNLOADS + "/DaftarKarkard/"
                val projection=arrayOf(android.provider.MediaStore.MediaColumns._ID)
                val selection=android.provider.MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+android.provider.MediaStore.MediaColumns.RELATIVE_PATH+"=?"
                val existing=resolver.query(collection,projection,selection,arrayOf(name,relative),null)
                var target:Uri?=null
                existing?.use { c -> if(c.moveToFirst()) target=Uri.withAppendedPath(collection,c.getLong(0).toString()) }
                if(target==null) {
                    val values=android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,name)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE,"application/octet-stream")
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,relative)
                    }
                    target=resolver.insert(collection,values)
                }
                val uri=target ?: throw IOException("Cannot create backup destination")
                resolver.openOutputStream(uri,"wt").use { out ->
                    if(out==null) throw IOException("Cannot open backup destination")
                    databaseFile.inputStream().use { it.copyTo(out) }
                }
            } else {
                val dir=File(getExternalFilesDir(null) ?: filesDir,"backups")
                if(!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create backup folder")
                val target=File(dir,"daftar-karkard-backup.db")
                databaseFile.inputStream().use { input -> target.outputStream().use { input.copyTo(it) } }
            }
            true
        } catch(e:Exception) { android.util.Log.e("DaftarKarkard","Backup failed",e); false }
    }

    private fun restoreBackup(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type="*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i,restoreReq)
    }

    private fun looksLikeSqlite(file:File):Boolean {
        if(!file.isFile || file.length()<100L) return false
        val header=ByteArray(16)
        file.inputStream().use { input ->
            if(input.read(header)!=16) return false
        }
        return String(header,Charsets.US_ASCII)=="SQLite format 3\u0000"
    }

    // Accept both the app's normal .db file and a ZIP containing a .db file.
    private fun materializeBackup(source:File, destination:File):File {
        if(looksLikeSqlite(source)) {
            source.copyTo(destination,true)
            return destination
        }
        val signature=ByteArray(4)
        source.inputStream().use { if(it.read(signature)!=4) throw IOException("فایل انتخاب‌شده خالی یا ناقص است") }
        val zipSignature=signature[0]=='P'.code.toByte() && signature[1]=='K'.code.toByte()
        if(!zipSignature) throw IOException("فرمت فایل پشتیبان شناخته نشد؛ فایل باید دیتابیس SQLite با پسوند DB باشد")
        var extracted=false
        java.util.zip.ZipInputStream(source.inputStream()).use { zip ->
            while(true) {
                val entry=zip.nextEntry ?: break
                if(!entry.isDirectory && (entry.name.endsWith(".db",true) || entry.name.endsWith(".sqlite",true) || entry.name.endsWith(".sqlite3",true))) {
                    destination.outputStream().use { out -> zip.copyTo(out) }
                    extracted=true
                    break
                }
                zip.closeEntry()
            }
        }
        if(!extracted || !looksLikeSqlite(destination)) {
            destination.delete()
            throw IOException("داخل فایل فشرده، دیتابیس معتبر با پسوند DB پیدا نشد")
        }
        return destination
    }

    private fun validateBackup(file:File) {
        if(!looksLikeSqlite(file)) throw IOException("فایل انتخاب‌شده دیتابیس SQLite معتبر نیست")
        val check=SQLiteDatabase.openDatabase(file.absolutePath,null,SQLiteDatabase.OPEN_READONLY)
        try {
            val integrity=check.rawQuery("PRAGMA quick_check",null).use { c ->
                if(c.moveToFirst()) c.getString(0) else "no result"
            }
            if(integrity!="ok") throw IOException("بررسی سلامت دیتابیس ناموفق بود: $integrity")
            val tables=mutableSetOf<String>()
            check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'",null).use { c ->
                while(c.moveToNext()) tables += c.getString(0)
            }
            val required=setOf("workers","works","projects","payments")
            if(!tables.containsAll(required)) {
                val missing=(required-tables).joinToString("، ")
                throw IOException("این فایل پشتیبان دفتر کارکرد من نیست؛ جدول‌های لازم موجود نیست: $missing")
            }
            if(check.version>4) throw IOException("این پشتیبان متعلق به نسخه جدیدتری از برنامه است")
            // Verify essential columns before touching the currently installed database.
            val requiredColumns=mapOf(
                "workers" to setOf("id","name"),
                "works" to setOf("id","worker_id","date","wage"),
                "projects" to setOf("id","name"),
                "payments" to setOf("id","worker_id","date","amount")
            )
            requiredColumns.forEach { (table,columns) ->
                val found=mutableSetOf<String>()
                check.rawQuery("PRAGMA table_info($table)",null).use { c ->
                    val ix=c.getColumnIndex("name")
                    while(c.moveToNext()) if(ix>=0) found += c.getString(ix)
                }
                if(!found.containsAll(columns)) throw IOException("ساختار جدول $table در فایل پشتیبان ناقص است")
            }
        } finally { check.close() }
    }

    private fun restoreDatabase(uri:Uri) {
        val live=getDatabasePath("daftar_native.db")
        val parent=live.parentFile ?: throw IOException("مسیر پایگاه داده در دسترس نیست")
        if(!parent.exists() && !parent.mkdirs()) throw IOException("مسیر ذخیره پایگاه داده ساخته نشد")

        // Stage in the same directory as the live database so replacement is an atomic rename.
        val incoming=File(parent,"daftar_native.incoming.db")
        val staged=File(parent,"daftar_native.staged.db")
        val previous=File(parent,"daftar_native.pre-restore.db")
        try {
            val input=contentResolver.openInputStream(uri) ?: throw IOException("فایل انتخاب‌شده قابل خواندن نیست")
            input.use { src -> incoming.outputStream().use { dst -> src.copyTo(dst) } }
            materializeBackup(incoming,staged)
            validateBackup(staged)

            db.close()
            File(live.absolutePath+"-wal").delete()
            File(live.absolutePath+"-shm").delete()
            previous.delete()

            if(live.exists() && !live.renameTo(previous)) {
                db=Db(this); db.writableDatabase
                throw IOException("نسخه فعلی دیتابیس قابل نگهداری موقت نبود؛ هیچ اطلاعاتی جایگزین نشد")
            }
            if(!staged.renameTo(live)) {
                if(previous.exists()) previous.renameTo(live)
                db=Db(this); db.writableDatabase
                throw IOException("جایگزینی فایل دیتابیس انجام نشد؛ نسخه قبلی حفظ شد")
            }

            try {
                db=Db(this)
                db.writableDatabase // idempotent migrations; confirms DB can be opened
                // Force queries used by the home page, not just opening the file.
                db.workers()
                db.projects()
                previous.delete()
                toast("بازیابی با موفقیت انجام شد؛ اطلاعات بارگذاری شدند")
                showHome()
            } catch(e:Exception) {
                try { db.close() } catch(_:Exception) {}
                live.delete()
                File(live.absolutePath+"-wal").delete()
                File(live.absolutePath+"-shm").delete()
                if(previous.exists() && !previous.renameTo(live)) {
                    throw IOException("بازیابی شکست خورد و بازگردانی خودکار نسخه قبلی هم ناموفق بود؛ فایل پشتیبان قبلی در مسیر خصوصی برنامه حفظ شده است")
                }
                db=Db(this)
                db.writableDatabase
                throw IOException("فایل انتخاب شد اما دیتابیس پس از جایگزینی باز نشد؛ نسخه قبلی برگردانده شد: ${e.message}")
            }
        } finally {
            incoming.delete()
            staged.delete()
        }
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==4107 || requestCode==4108) {
            val callback=workerPhotoPickerCallback
            if(resultCode==Activity.RESULT_OK) {
                try {
                    val bitmap=if(requestCode==4108) {
                        @Suppress("DEPRECATION")
                        data?.extras?.get("data") as? Bitmap
                    } else {
                        data?.data?.let { uri -> contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
                    }
                    callback?.invoke(bitmap)
                } catch(e:Exception) { toast("خواندن عکس ناموفق بود") }
            } else callback?.invoke(null)
            return
        }
        if(resultCode!=RESULT_OK) return
        val uri=data?.data
        if(uri==null) {
            if(requestCode==restoreReq) toast("فایل انتخاب شد اما مسیر فایل از مدیر فایل دریافت نشد؛ دوباره از حافظه داخلی انتخاب کن")
            return
        }
        try {
            if(requestCode==backupReq) {
                val f=getDatabasePath("daftar_native.db")
                contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { input -> input.copyTo(out) } }
                    ?: throw IOException("امکان ذخیره فایل وجود ندارد")
                toast("پشتیبان ذخیره شد")
            } else if(requestCode==restoreReq) {
                restoreDatabase(uri)
            }
        } catch(e:Exception) {
            android.util.Log.e("DaftarKarkard","Restore failed",e)
            toast("بازیابی ناموفق بود: ${e.message ?: "خطای ناشناخته"}")
        }
    }
    private fun fmt(v:Long)=String.format(Locale.US,"%,d",v)
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}