package com.example.daftarkarkard

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import java.util.concurrent.Executor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

data class Worker(val id: Long, val name: String, val currency: String = "دینار")
data class Project(val id: Long, val name: String, val currency: String = "دینار")
data class ProjectExpense(val id: Long, val date: String, val category: String, val amount: Long, val note: String)
data class ProjectMaterial(val id: Long, val date: String, val name: String, val quantity: Double, val unit: String, val unitPrice: Long, val note: String)
data class Work(val id: Long, val workerId: Long, val date: String, val start: String, val end: String,
                val wage: Long, val overtime: Double, val note: String, val projectId: Long? = null)
data class Payment(val id: Long, val workerId: Long, val date: String, val amount: Long, val note: String, val projectId: Long? = null)

class Db(context: Context) : SQLiteOpenHelper(context, "daftar_native.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, currency TEXT NOT NULL DEFAULT 'دینار')")
        db.execSQL("CREATE TABLE works(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, date TEXT NOT NULL, start TEXT, end TEXT, wage INTEGER NOT NULL, overtime REAL NOT NULL DEFAULT 0, note TEXT, project_id INTEGER)")
        db.execSQL("CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, currency TEXT NOT NULL DEFAULT 'دینار')")
        db.execSQL("CREATE TABLE project_expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT)")
        db.execSQL("CREATE TABLE project_materials(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, unit_price INTEGER NOT NULL, note TEXT)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, worker_id INTEGER NOT NULL, date TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, project_id INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if(oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
            db.execSQL("ALTER TABLE works ADD COLUMN project_id INTEGER")
            db.execSQL("ALTER TABLE payments ADD COLUMN project_id INTEGER")
        }
        if(oldVersion < 3) {
            db.execSQL("ALTER TABLE workers ADD COLUMN currency TEXT NOT NULL DEFAULT 'دینار'")
            db.execSQL("ALTER TABLE projects ADD COLUMN currency TEXT NOT NULL DEFAULT 'دینار'")
            db.execSQL("CREATE TABLE project_expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT)")
            db.execSQL("CREATE TABLE project_materials(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, date TEXT NOT NULL, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, unit_price INTEGER NOT NULL, note TEXT)")
        }
    }
    fun projects():List<Project> {
        val out= mutableListOf<Project>()
        readableDatabase.rawQuery("SELECT id,name,currency FROM projects ORDER BY name",null).use { c -> while(c.moveToNext()) out += Project(c.getLong(0),c.getString(1),c.getString(2) ?: "دینار") }
        return out
    }
    fun addProject(name:String,currency:String) { writableDatabase.execSQL("INSERT INTO projects(name,currency) VALUES(?,?)", arrayOf(name.trim(),currency)) }
    fun renameProject(id:Long,name:String,currency:String) { writableDatabase.execSQL("UPDATE projects SET name=?,currency=? WHERE id=?",arrayOf(name.trim(),currency,id)) }
    fun deleteProject(id:Long) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.execSQL("UPDATE works SET project_id=NULL WHERE project_id=?",arrayOf(id))
            writableDatabase.execSQL("UPDATE payments SET project_id=NULL WHERE project_id=?",arrayOf(id))
            writableDatabase.delete("project_expenses","project_id=?",arrayOf(id.toString()))
            writableDatabase.delete("project_materials","project_id=?",arrayOf(id.toString()))
            writableDatabase.delete("projects","id=?",arrayOf(id.toString()))
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun addProjectExpense(projectId:Long,date:String,category:String,amount:Long,note:String) { writableDatabase.execSQL("INSERT INTO project_expenses(project_id,date,category,amount,note) VALUES(?,?,?,?,?)",arrayOf(projectId,date,category,amount,note)) }
    fun projectExpenses(projectId:Long):List<ProjectExpense> { val a=mutableListOf<ProjectExpense>(); readableDatabase.rawQuery("SELECT id,date,category,amount,note FROM project_expenses WHERE project_id=? ORDER BY date DESC",arrayOf(projectId.toString())).use { c -> while(c.moveToNext()) a += ProjectExpense(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getString(4) ?: "") }; return a }
    fun addProjectMaterial(projectId:Long,date:String,name:String,quantity:Double,unit:String,unitPrice:Long,note:String) { writableDatabase.execSQL("INSERT INTO project_materials(project_id,date,name,quantity,unit,unit_price,note) VALUES(?,?,?,?,?,?,?)",arrayOf(projectId,date,name,quantity,unit,unitPrice,note)) }
    fun projectMaterials(projectId:Long):List<ProjectMaterial> { val a=mutableListOf<ProjectMaterial>(); readableDatabase.rawQuery("SELECT id,date,name,quantity,unit,unit_price,note FROM project_materials WHERE project_id=? ORDER BY date DESC",arrayOf(projectId.toString())).use { c -> while(c.moveToNext()) a += ProjectMaterial(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4),c.getLong(5),c.getString(6) ?: "") }; return a }
    fun projectName(id:Long?):String = if(id==null) "بدون پروژه" else projects().firstOrNull{it.id==id}?.name ?: "پروژه حذف‌شده"
    fun projectWorks(id:Long):List<Work> = allWorks().filter { it.projectId==id }
    fun projectWorkers(id:Long):List<Long> = projectWorks(id).map{it.workerId}.distinct()
    fun workers(): List<Worker> {
        val out= mutableListOf<Worker>(); readableDatabase.rawQuery("SELECT id,name,currency FROM workers ORDER BY name",null).use { c -> while(c.moveToNext()) out += Worker(c.getLong(0),c.getString(1),c.getString(2) ?: "دینار") }; return out
    }
    fun addWorker(name:String,currency:String) { writableDatabase.execSQL("INSERT INTO workers(name,currency) VALUES(?,?)", arrayOf(name.trim(),currency)) }
    fun deleteWorker(id:Long) { writableDatabase.beginTransaction(); try { writableDatabase.delete("works","worker_id=?", arrayOf(id.toString())); writableDatabase.delete("payments","worker_id=?", arrayOf(id.toString())); writableDatabase.delete("workers","id=?",arrayOf(id.toString())); writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() } }
    fun works(worker:Long):List<Work> { val a= mutableListOf<Work>(); readableDatabase.rawQuery("SELECT id,worker_id,date,start,end,wage,overtime,note,project_id FROM works WHERE worker_id=? ORDER BY date DESC,id DESC",arrayOf(worker.toString())).use { c -> while(c.moveToNext()) a += Work(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3)?: "",c.getString(4)?: "",c.getLong(5),c.getDouble(6),c.getString(7)?: "",if(c.isNull(8)) null else c.getLong(8)) }; return a }
    fun allWorks():List<Work> = workers().flatMap { works(it.id) }
    fun addWorks(ids:List<Long>, date:String, start:String, end:String, wage:Long, ot:Double, note:String, projectId:Long?=null) {
        writableDatabase.beginTransaction(); try { ids.forEach { writableDatabase.execSQL("INSERT INTO works(worker_id,date,start,end,wage,overtime,note,project_id) VALUES(?,?,?,?,?,?,?,?)",arrayOf(it,date,start,end,wage,ot,note,projectId)) }; writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() }
    }
    fun updateWork(w:Work) { writableDatabase.execSQL("UPDATE works SET date=?,start=?,end=?,wage=?,overtime=?,note=?,project_id=? WHERE id=?",arrayOf(w.date,w.start,w.end,w.wage,w.overtime,w.note,w.projectId,w.id)) }
    fun deleteWork(id:Long) { writableDatabase.delete("works","id=?",arrayOf(id.toString())) }
    fun payments(worker:Long):List<Payment> { val a= mutableListOf<Payment>(); readableDatabase.rawQuery("SELECT id,worker_id,date,amount,note,project_id FROM payments WHERE worker_id=? ORDER BY date DESC",arrayOf(worker.toString())).use { c -> while(c.moveToNext()) a += Payment(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4)?: "",if(c.isNull(5)) null else c.getLong(5)) }; return a }
    fun addPayment(worker:Long,date:String,amount:Long,note:String,projectId:Long?=null) { writableDatabase.execSQL("INSERT INTO payments(worker_id,date,amount,note,project_id) VALUES(?,?,?,?,?)",arrayOf(worker,date,amount,note,projectId)) }
    fun projectPaid(projectId:Long):Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE project_id=?",arrayOf(projectId.toString())).use { c -> if(c.moveToFirst()) c.getLong(0) else 0L }
    fun projectPayments(projectId:Long):List<Payment> {
        val out=mutableListOf<Payment>()
        readableDatabase.rawQuery("SELECT id,worker_id,date,amount,note,project_id FROM payments WHERE project_id=? ORDER BY date DESC",arrayOf(projectId.toString())).use { c ->
            while(c.moveToNext()) out += Payment(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4)?: "",if(c.isNull(5)) null else c.getLong(5))
        }
        return out
    }
    fun deletePayment(id:Long) { writableDatabase.delete("payments","id=?",arrayOf(id.toString())) }
    fun total(worker:Long):Long = works(worker).filterNot { it.note.trim()=="تعطیل" }.sumOf { it.wage + (it.wage*it.overtime/8.0).toLong() }
    fun paid(worker:Long):Long = payments(worker).sumOf { it.amount }
}

class MainActivity : FragmentActivity() {
    private lateinit var db: Db
    private lateinit var content: LinearLayout
    // Visual system inspired by the reference screenshots: soft neutral canvas,
    // purple primary, teal/green accents and spacious rounded cards.
    private val green=Color.rgb(151,137,255)       // One UI-inspired lavender accent
    private val headerPurple=Color.rgb(54,42,112)
    private val teal=Color.rgb(45,190,164)          // mint
    private val canvasColor=Color.rgb(24,31,45)     // deep blue-grey, not pure black
    private val ink=Color.rgb(246,247,252)          // primary text
    private val muted=Color.rgb(173,183,201)        // secondary text
    private val red=Color.rgb(255,111,137)          // coral
    private val blue=Color.rgb(76,166,255)          // Samsung-style blue
    private val surface=Color.rgb(34,44,62)
    private val surfaceAlt=Color.rgb(43,56,78)
    private val outline=Color.rgb(59,73,96)
    private val prefs by lazy { getSharedPreferences("ui_settings", MODE_PRIVATE) }
    private fun currency() = prefs.getString("currency", "دینار") ?: "دینار"
    private fun jalali() = prefs.getBoolean("jalali", false)
    private var currentWorker:Worker?=null
    private var currentBack:()->Unit = { showHome() }
    private var isDashboardPage:Boolean = true
    private val backupReq=501
    private val restoreReq=502

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep app content between the system bars so the header and bottom navigation
        // are never hidden behind Android's status/navigation bars (Android 15+ too).
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor=headerPurple
        window.navigationBarColor=canvasColor
        window.decorView.systemUiVisibility=0 // white status icons on the purple status bar
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        db=Db(this)
        if(prefs.getBoolean("biometric",false)) authenticate() else showHome()
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the app navigation")
    override fun onBackPressed() {
        if(isDashboardPage) showExitDialog() else currentBack()
    }

    private fun showExitDialog() {
        val dialog=AlertDialog.Builder(this)
            .setTitle("خروج از دفتر کار من")
            .setMessage("برای خروج، یکی از روش‌های زیر را انتخاب کنید.")
            .setPositiveButton("پشتیبان‌گیری و خروج",null)
            .setNegativeButton("خروج",null)
            .setNeutralButton("ادامه کار",null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(rounded(surface,20))
            dialog.getButton(-1).setTextColor(teal)
            dialog.getButton(-2).setTextColor(red)
            dialog.getButton(-3).setTextColor(muted)
            dialog.getButton(-1).setOnClickListener {
                if(saveSingleBackup()) { toast("پشتیبان ذخیره و به‌روزرسانی شد"); dialog.dismiss(); finish() }
                else toast("پشتیبان‌گیری انجام نشد؛ برنامه باز می‌ماند")
            }
            dialog.getButton(-2).setOnClickListener { dialog.dismiss(); finish() }
        }
        dialog.show()
    }

    private fun authenticate() {
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object: BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { super.onAuthenticationSucceeded(result); showHome() }
            override fun onAuthenticationError(code:Int, message:CharSequence) { super.onAuthenticationError(code,message); if(code==BiometricPrompt.ERROR_NEGATIVE_BUTTON || code==BiometricPrompt.ERROR_USER_CANCELED) finish() else toast("ورود با اثر انگشت انجام نشد: $message") }
            override fun onAuthenticationFailed() { super.onAuthenticationFailed(); toast("اثر انگشت شناسایی نشد") }
        })
        val info=BiometricPrompt.PromptInfo.Builder().setTitle("قفل دفتر کارکرد من").setSubtitle("برای ورود، اثر انگشت یا قفل دستگاه را تأیید کنید").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG.or(BiometricManager.Authenticators.DEVICE_CREDENTIAL)).build()
        prompt.authenticate(info)
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun label(t:String,size:Float=16f):TextView = TextView(this).apply {
        text=t; textSize=size; setTextColor(ink); gravity=Gravity.RIGHT
        setPadding(dp(8),dp(7),dp(8),dp(7)); textDirection=View.TEXT_DIRECTION_RTL
    }
    private fun button(t:String, action:()->Unit):Button = Button(this).apply {
        text=t; isAllCaps=false; textSize=14f; textDirection=View.TEXT_DIRECTION_RTL
        setTextColor(Color.WHITE); background=rounded(teal,16); elevation=0f
        minHeight=dp(48); setPadding(dp(12),dp(5),dp(12),dp(5)); setOnClickListener { action() }
    }
    private fun smallActionButton(t:String, color:Int=teal, action:()->Unit):Button = Button(this).apply {
        text=t; isAllCaps=false; textSize=12f; setTextColor(Color.WHITE)
        minHeight=dp(34); minimumHeight=dp(34); setPadding(dp(8),0,dp(8),0)
        background=rounded(color,12); setOnClickListener { action() }
    }
    private fun card():LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12))
        background=rounded(surface,20); elevation=0f
    }
    private fun rounded(color:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius=dp(r).toFloat(); setStroke(dp(1),outline)
    }
    private fun bottomRounded(color:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        val radius=dp(r).toFloat()
        cornerRadii=floatArrayOf(0f,0f,0f,0f,radius,radius,radius,radius)
    }
    private fun isHoliday(work:Work)=work.note.trim()=="تعطیل"
    private fun addGap(target:LinearLayout=content, height:Int=8) {
        target.addView(View(this),LinearLayout.LayoutParams(1,dp(height)))
    }
    private fun statCard(title:String,value:String,accent:Int):LinearLayout = card().apply {
        setPadding(dp(9),dp(9),dp(9),dp(9))
        addView(label(title,11f).apply { setTextColor(muted) })
        addView(label(value,15f).apply { setTextColor(accent); setTypeface(null,android.graphics.Typeface.BOLD) })
    }
    private fun actionTile(title:String, subtitle:String="", action:()->Unit):LinearLayout = card().apply {
        isClickable=true; isFocusable=true
        addView(label(title,16f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        if(subtitle.isNotBlank()) addView(label(subtitle,11f).apply { setTextColor(muted) })
        setOnClickListener { action() }
    }
    private fun base(title:String, onBack:()->Unit = { showHome() }) {
        currentBack=onBack
        isDashboardPage = title == "داشبورد"
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setBackgroundColor(canvasColor)
            // Reserve space for Android's bottom navigation/gesture area.
            setPadding(0,0,0,dp(8))
        }
        val header=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT
            // Flush with the top and side edges; only the lower corners are rounded.
            setPadding(dp(20),dp(22),dp(20),dp(18))
            background=bottomRounded(headerPurple,26)
        }
        header.addView(TextView(this).apply { text=title; textSize=23f; setTextColor(Color.WHITE); gravity=Gravity.RIGHT; setTypeface(null,android.graphics.Typeface.BOLD); textDirection=View.TEXT_DIRECTION_RTL })
        header.addView(TextView(this).apply { text="دفتر کارکرد من  •  مدیریت کارکرد و حساب‌ها"; textSize=11f; setTextColor(Color.rgb(235,232,255)); gravity=Gravity.RIGHT; setPadding(0,dp(4),0,0); textDirection=View.TEXT_DIRECTION_RTL })
        root.addView(header,LinearLayout.LayoutParams(-1,-2))
        val scroll=ScrollView(this).apply { clipToPadding=false }
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(24)) }
        scroll.addView(content)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        // Compact floating navigation pill, separated from Android system navigation.
        val footer=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER
            layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(dp(5),dp(2),dp(5),dp(2)); background=rounded(headerPurple,28)
            elevation=dp(12).toFloat()
        }
        fun navButton(title:String, action:()->Unit)=Button(this).apply {
            // Persian text only: no glyphs, emoji, or Latin characters.
            text=title
            isAllCaps=false
            textSize=12.5f
            setTextColor(Color.WHITE)
            gravity=Gravity.CENTER
            minHeight=dp(40); minimumHeight=dp(40)
            setPadding(dp(2),0,dp(2),0)
            background=rounded(Color.TRANSPARENT,18).apply { setStroke(0,Color.TRANSPARENT) }
            setOnClickListener { action() }
        }
        val home=navButton("خانه") { showHome() }
        val people=navButton("اشخاص") { showPeople() }
        val backup=navButton("پشتیبان") { createBackup() }
        val back=navButton("بازگشت") { currentBack() }
        listOf(home,people,backup,back).forEach {
            footer.addView(it,LinearLayout.LayoutParams(0,dp(42),1f).apply { setMargins(dp(1),0,dp(1),0) })
        }
        // Keep a visible gap above Samsung's system navigation bar.
        root.addView(footer,LinearLayout.LayoutParams(-1,dp(46)).apply {
            setMargins(dp(18),dp(5),dp(18),dp(42))
        })
        setContentView(root)
    }
    private fun row(vararg views:View) = rowIn(content,*views)
    private fun rowIn(target:LinearLayout,vararg views:View) {
        val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        views.forEach { r.addView(it,LinearLayout.LayoutParams(0,-2,1f).apply { setMargins(dp(3),0,dp(3),0) }) }
        target.addView(r)
    }
    private fun showHome() {
        base("داشبورد")
        val all=db.workers()
        val total=all.sumOf { db.total(it.id) }; val paid=all.sumOf { db.paid(it.id) }
        val balance=total-paid
        content.addView(card().apply {
            addView(label("خلاصه وضعیت حساب‌ها",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            addGap(this,4)
            addView(label("جمع عددی همه پرونده‌ها (واحدهای پولی ممکن است متفاوت باشند): ${fmt(total)}",12f).apply { setTextColor(muted) })
            addView(label("جمع دریافتی عددی: ${fmt(paid)}   |   مانده عددی: ${fmt(balance)}",12f).apply { setTextColor(muted) })
        })
        addGap()
        content.addView(label("دسترسی سریع",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        row(actionTile("＋ افزودن شخص","ساخت پرونده جدید") { workerDialog() }, actionTile("⚙ تنظیمات","واحد پول، تقویم و قفل") { settingsScreen() })
        addGap(content)
        row(actionTile("ثبت کارکرد گروهی","برای چند شخص هم‌زمان") { batchWorkDialog() }, actionTile("ثبت دریافتی","ثبت پرداخت شخص") { paymentWorkerDialog() })
        addGap()
        content.addView(label("اشخاص و پرونده‌ها  (${all.size})",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        if(all.isEmpty()) content.addView(card().apply { addView(label("هنوز شخصی ثبت نشده است. از گزینه افزودن شخص شروع کن.")) })
        all.forEach { w ->
            val workList=db.works(w.id)
            val days=workList.filterNot { isHoliday(it) }.map { it.date }.distinct().size
            val c=card()
            c.addView(label(w.name,19f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            c.addView(label("روزهای کاری ثبت‌شده: $days",13f).apply { setTextColor(muted) })
            rowIn(c,
                statCard("کارکرد", "${fmt(db.total(w.id))} ${w.currency}",green),
                statCard("دریافتی", "${fmt(db.paid(w.id))} ${w.currency}",teal),
                statCard("مانده", "${fmt(db.total(w.id)-db.paid(w.id))} ${w.currency}",red))
            addGap(c,6)
            rowIn(c,
                button("ورود به پرونده  ←") { currentWorker=w; showWorker(w) },
                button("حذف پرونده") { confirm("شخص و تمام سوابق او حذف شود؟") { db.deleteWorker(w.id); showHome() } }.apply { background=rounded(red,14) }
            )
            content.addView(c); addGap()
        }
        content.addView(card().apply {
            addView(label("پشتیبان‌گیری و بازیابی",16f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            addView(label("می‌توانی فایل پشتیبان را در گوشی ذخیره کنی یا از پنجره انتخاب فایل، Google Drive متصل به حساب جیمیل خودت را انتخاب کنی.",12f).apply { setTextColor(muted) })
            rowIn(this,actionTile("ذخیره پشتیبان") { createBackup() },actionTile("بازیابی پشتیبان") { restoreBackup() })
        })
    }
    private fun showPeople() {
        base("اشخاص")
        val all=db.workers()
        content.addView(button("＋ افزودن شخص") { workerDialog() })
        addGap()
        if(all.isEmpty()) {
            content.addView(card().apply { addView(label("هنوز شخصی ثبت نشده است.")) })
        }
        all.forEach { w ->
            val workList=db.works(w.id)
            val days=workList.filterNot { isHoliday(it) }.map { it.date }.distinct().size
            content.addView(card().apply {
                addView(label(w.name,18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                addView(label("روزهای کاری: $days",12f).apply { setTextColor(muted) })
                rowIn(this,
                    statCard("کارکرد", "${fmt(db.total(w.id))} ${w.currency}",green),
                    statCard("دریافتی", "${fmt(db.paid(w.id))} ${w.currency}",teal),
                    statCard("مانده", "${fmt(db.total(w.id)-db.paid(w.id))} ${w.currency}",red))
                addGap(this,6)
                addView(button("ورود به پرونده  ←") { currentWorker=w; showWorker(w) })
            })
            addGap()
        }
    }

    private fun currencySpinner(selected:String?=null):Spinner {
        val values=arrayOf("دینار","دلار","ریال")
        return Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,values); setSelection(values.indexOf(selected ?: currency()).coerceAtLeast(0)) }
    }
    private fun workerDialog() {
        val input=EditText(this).apply { hint="نام شخص"; textDirection=View.TEXT_DIRECTION_RTL }
        val currency=currencySpinner()
        formDialog("افزودن شخص", listOf(input,currency)) {
            val n=input.text.toString().trim()
            if(n.isEmpty()) { toast("نام را وارد کنید"); false } else { db.addWorker(n,currency.selectedItem.toString()); showHome(); true }
        }
    }
    private fun showWorker(w:Worker, showPayments:Boolean=false) {
        base("پرونده ${w.name}") { showPeople() }
        val works=db.works(w.id); val days=works.filterNot { isHoliday(it) }.map { it.date }.distinct().size
        content.addView(card().apply {
            addView(label("خلاصه حساب شخص",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            rowIn(this,statCard("کارکرد","${fmt(db.total(w.id))} ${w.currency}",green),
                statCard("دریافتی","${fmt(db.paid(w.id))} ${w.currency}",teal),
                statCard("مانده","${fmt(db.total(w.id)-db.paid(w.id))} ${w.currency}",red))
            addView(label("روزهای کاری: $days",12f).apply { setTextColor(muted) })
        })
        addGap()
        row(actionTile("ثبت کارکرد","افزودن روز کاری") { workDialog(listOf(w.id)) },actionTile("ثبت دریافتی","ثبت پرداخت") { paymentDialog(w) })
        addGap(content)
        row(actionTile("گزارش ماهانه / سالانه","تعداد روز، اضافه‌کاری و مبالغ") { reportDialog(w) },actionTile("خروجی PDF","خلاصه حساب") { exportPdf(w) })
        addGap()
        val tabs=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER
            background=rounded(surface,16); setPadding(dp(4),dp(4),dp(4),dp(4))
        }
        val workTab=Button(this).apply {
            text="ریزکارکردها"; isAllCaps=false; textSize=13f; minHeight=dp(38); minimumHeight=dp(38)
            setTextColor(Color.WHITE); background=rounded(if(!showPayments) headerPurple else Color.TRANSPARENT,12)
            setOnClickListener { showWorker(w,false) }
        }
        val paymentTab=Button(this).apply {
            text="دریافتی‌ها"; isAllCaps=false; textSize=13f; minHeight=dp(38); minimumHeight=dp(38)
            setTextColor(Color.WHITE); background=rounded(if(showPayments) headerPurple else Color.TRANSPARENT,12)
            setOnClickListener { showWorker(w,true) }
        }
        tabs.addView(workTab,LinearLayout.LayoutParams(0,dp(42),1f))
        tabs.addView(paymentTab,LinearLayout.LayoutParams(0,dp(42),1f))
        content.addView(tabs); addGap()
        if(!showPayments) {
            if(works.isEmpty()) content.addView(card().apply { addView(label("هنوز ریزکارکردی ثبت نشده است.",13f).apply { setTextColor(muted) }) })
            works.forEach { item ->
                val c=card(); c.addView(label(dateLabel(item.date),15f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                if(isHoliday(item)) {
                    c.addView(label("تعطیل",15f).apply { setTextColor(Color.rgb(255,75,85)); setTypeface(null,android.graphics.Typeface.BOLD) })
                } else {
                    c.addView(label("پروژه: ${db.projectName(item.projectId)}",12f).apply { setTextColor(green) })
                    c.addView(label("دستمزد ${fmt(item.wage)} ${w.currency}  •  اضافه‌کاری ${item.overtime} ساعت"))
                    c.addView(label("شروع ${item.start}   |   پایان ${item.end}   |   مبلغ نهایی ${fmt(item.wage+(item.wage*item.overtime/8.0).toLong())} ${w.currency}"))
                    if(item.note.isNotBlank()) c.addView(label(item.note,13f).apply { setTextColor(muted) })
                }
                val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
                actions.addView(smallActionButton("ویرایش",teal) { editWorkDialog(item,w) },
                    LinearLayout.LayoutParams(0,dp(36),1f).apply { setMargins(dp(3),0,dp(3),0) })
                actions.addView(smallActionButton("حذف",red) { confirm("این رکورد حذف شود؟") { db.deleteWork(item.id); showWorker(w,false) } },
                    LinearLayout.LayoutParams(0,dp(36),1f).apply { setMargins(dp(3),0,dp(3),0) })
                c.addView(actions); content.addView(c); addGap()
            }
        } else {
            val payments=db.payments(w.id)
            if(payments.isEmpty()) content.addView(card().apply { addView(label("هنوز دریافتی ثبت نشده است.",13f).apply { setTextColor(muted) }) })
            payments.forEach { p -> content.addView(card().apply {
                addView(label(dateLabel(p.date),15f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                addView(label("مبلغ دریافتی: ${fmt(p.amount)} ${w.currency}"))
                if(p.projectId!=null) addView(label("پروژه: ${db.projectName(p.projectId)}",12f).apply { setTextColor(green) })
                if(p.note.isNotBlank()) addView(label(p.note,13f).apply { setTextColor(muted) })
                addView(smallActionButton("حذف دریافتی",red) { confirm("این دریافتی حذف شود؟") { db.deletePayment(p.id); showWorker(w,true) } })
            }); addGap() }
        }
    }

    private fun projectsScreen() {
        base("پروژه‌ها") { settingsScreen() }
        content.addView(button("＋ افزودن پروژه") { projectDialog() })
        addGap()
        val all=db.projects()
        if(all.isEmpty()) content.addView(card().apply { addView(label("هنوز پروژه‌ای ثبت نشده است.")) })
        all.forEach { p ->
            val works=db.projectWorks(p.id)
            val workDays=works.filterNot { isHoliday(it) }.map { it.date }.distinct().size
            val total=works.filterNot { isHoliday(it) }.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong() }
            val people=works.map { it.workerId }.distinct().size
            content.addView(card().apply {
                addView(label(p.name,18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                rowIn(this,statCard("روز کاری",workDays.toString(),green),statCard("اشخاص",people.toString(),teal),statCard("جمع کارکرد", "${fmt(total)} ${p.currency}",green))
                addGap(this,6)
                addView(button("مشاهده گزارش پروژه  ←") { projectDetail(p) })
                addGap(this,12)
                rowIn(this,
                    smallActionButton("ویرایش نام",teal) { projectDialog(p) },
                    smallActionButton("حذف پروژه",red) { confirm("پروژه حذف شود؟ سوابق کارکرد حفظ و از پروژه جدا می‌شوند.") { db.deleteProject(p.id); projectsScreen() } })
            })
            addGap()
        }
    }
    private fun projectDialog(project:Project?=null) {
        val input=EditText(this).apply { hint="نام پروژه"; project?.let { setText(it.name) } }
        val currency=currencySpinner(project?.currency)
        formDialog(if(project==null) "افزودن پروژه" else "ویرایش پروژه",listOf(input,currency)) {
            val name=input.text.toString().trim()
            if(name.isBlank()) { toast("نام پروژه را وارد کنید"); false }
            else try { if(project==null) db.addProject(name,currency.selectedItem.toString()) else db.renameProject(project.id,name,currency.selectedItem.toString()); projectsScreen(); true }
            catch(_:Exception) { toast("این نام پروژه قبلاً ثبت شده است"); false }
        }
    }
    private fun projectDetail(project:Project) {
        base(project.name) { projectsScreen() }
        val works=db.projectWorks(project.id)
        val regular=works.filterNot { isHoliday(it) }
        val total=regular.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong() }
        val peopleIds=regular.map { it.workerId }.distinct()
        val paidByProject=db.projectPaid(project.id)
        val extraExpenses=db.projectExpenses(project.id).sumOf { it.amount }
        val materialCosts=db.projectMaterials(project.id).sumOf { (it.quantity*it.unitPrice).toLong() }
        content.addView(card().apply {
            addView(label("خلاصه پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
            rowIn(this,statCard("روز کاری",regular.map{it.date}.distinct().size.toString(),green),statCard("تعداد اشخاص",peopleIds.size.toString(),teal))
            rowIn(this,statCard("جمع کارکرد", "${fmt(total)} ${project.currency}",green),statCard("پرداخت مرتبط با پروژه",fmt(paidByProject),teal))
            addView(label("هزینه‌های جانبی: ${fmt(extraExpenses)} ${project.currency}"))
            addView(label("هزینه مصالح و کالا: ${fmt(materialCosts)} ${project.currency}"))
            addView(label("مانده پس از پرداخت‌ها و هزینه‌ها: ${fmt(total+extraExpenses+materialCosts-paidByProject)} ${project.currency}",14f).apply { setTextColor(if(total+extraExpenses+materialCosts-paidByProject>=0) red else teal) })
            addView(label("توجه: واحد پول دستمزدها مطابق پرونده هر شخص است؛ جمع کارکرد پروژه، جمع عددی مبالغ ثبت‌شده است.",11f).apply { setTextColor(muted) })
            addView(label("روزهای تعطیل: ${works.count{isHoliday(it)}}",12f).apply { setTextColor(red) })
        })
        addGap()
        content.addView(label("کارکردهای پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        works.sortedByDescending{it.date}.forEach { item ->
            val workerForItem=db.workers().firstOrNull{it.id==item.workerId}
            val person=workerForItem?.name ?: "شخص حذف‌شده"
            val workCurrency=workerForItem?.currency ?: "دینار"
            content.addView(card().apply {
                addView(label("$person  •  ${dateLabel(item.date)}",14f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
                if(isHoliday(item)) addView(label("تعطیل",14f).apply { setTextColor(red) })
                else addView(label("مبلغ: ${fmt(item.wage+(item.wage*item.overtime/8.0).toLong())} $workCurrency"))
            })
            addGap()
        }
        if(works.isEmpty()) content.addView(label("برای این پروژه هنوز کارکردی ثبت نشده است."))
        addGap()
        content.addView(label("پرداخت‌های ثبت‌شده برای پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        val projectPayments=db.projectPayments(project.id)
        if(projectPayments.isEmpty()) content.addView(label("هنوز پرداختی به این پروژه اختصاص داده نشده است.",13f).apply { setTextColor(muted) })
        projectPayments.forEach { payment ->
            val person=db.workers().firstOrNull{it.id==payment.workerId}?.name ?: "شخص حذف‌شده"
            content.addView(card().apply {
                addView(label("$person  •  ${dateLabel(payment.date)}",14f))
                addView(label("پرداخت: ${fmt(payment.amount)} ${project.currency}"))
                if(payment.note.isNotBlank()) addView(label(payment.note,12f).apply { setTextColor(muted) })
            })
            addGap()
        }
        addGap()
        content.addView(label("هزینه‌های جانبی پروژه",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        content.addView(button("＋ ثبت هزینه خوراک، حمل‌ونقل یا سایر") { addProjectExpenseDialog(project) })
        val expenses=db.projectExpenses(project.id)
        expenses.forEach { e -> content.addView(card().apply { addView(label("${e.category} • ${dateLabel(e.date)}",14f)); addView(label("${fmt(e.amount)} ${project.currency}")); if(e.note.isNotBlank()) addView(label(e.note,12f).apply { setTextColor(muted) }) }); addGap() }
        if(expenses.isEmpty()) content.addView(label("هزینه جانبی ثبت نشده است.",12f).apply { setTextColor(muted) })
        addGap()
        content.addView(label("مصالح و کالاهای خریداری‌شده",18f).apply { setTypeface(null,android.graphics.Typeface.BOLD) })
        content.addView(button("＋ ثبت خرید مصالح یا کالا") { addProjectMaterialDialog(project) })
        val materials=db.projectMaterials(project.id)
        materials.forEach { m -> content.addView(card().apply { addView(label("${m.name} • ${dateLabel(m.date)}",14f)); addView(label("مقدار: ${m.quantity} ${m.unit} × ${fmt(m.unitPrice)} ${project.currency}")); addView(label("جمع: ${fmt((m.quantity*m.unitPrice).toLong())} ${project.currency}")); if(m.note.isNotBlank()) addView(label(m.note,12f).apply { setTextColor(muted) }) }); addGap() }
        if(materials.isEmpty()) content.addView(label("خریدی ثبت نشده است.",12f).apply { setTextColor(muted) })
    }

    private fun addProjectExpenseDialog(project:Project) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val category=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("خوراک","حمل‌ونقل","سایر")) }
        val amount=EditText(this).apply { hint="مبلغ (${project.currency})"; inputType=2 }
        val note=EditText(this).apply { hint="توضیحات (اختیاری)" }
        formDialog("ثبت هزینه جانبی پروژه",listOf(date,category,amount,note)) {
            val v=amount.text.toString().toLongOrNull()
            if(v==null || v<0 || date.text.isBlank()) { toast("تاریخ و مبلغ را بررسی کنید"); false }
            else { db.addProjectExpense(project.id,toGregorian(date.text.toString()),category.selectedItem.toString(),v,note.text.toString()); projectDetail(project); true }
        }
    }
    private fun addProjectMaterialDialog(project:Project) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val name=EditText(this).apply { hint="نام کالا یا مصالح" }
        val quantity=EditText(this).apply { hint="تعداد / مقدار"; inputType=8194 }
        val unit=EditText(this).apply { hint="واحد (عدد، کیلو، متر و...)" }
        val price=EditText(this).apply { hint="قیمت واحد (${project.currency})"; inputType=2 }
        val note=EditText(this).apply { hint="توضیحات (اختیاری)" }
        formDialog("ثبت خرید مصالح و کالا",listOf(date,name,quantity,unit,price,note)) {
            val q=quantity.text.toString().replace(',','.').toDoubleOrNull(); val v=price.text.toString().toLongOrNull(); val n=name.text.toString().trim()
            if(date.text.isBlank() || n.isBlank() || q==null || q<=0 || v==null || v<0 || unit.text.isBlank()) { toast("اطلاعات خرید را بررسی کنید"); false }
            else { db.addProjectMaterial(project.id,toGregorian(date.text.toString()),n,q,unit.text.toString().trim(),v,note.text.toString()); projectDetail(project); true }
        }
    }

    private fun settingsScreen() {
        base("تنظیمات برنامه")
        content.addView(button("مدیریت پروژه‌ها  ›") { projectsScreen() })
        addGap()
        content.addView(label("واحد پول",18f))
        val currencies=arrayOf("دینار","دلار","ریال")
        val currencySpinner=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,currencies); setSelection(currencies.indexOf(currency()).coerceAtLeast(0)) }
        content.addView(currencySpinner)
        content.addView(label("تقویم پیش‌فرض",18f))
        val calendars=arrayOf("میلادی","ایرانی (شمسی)")
        val calendarSpinner=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,calendars); setSelection(if(jalali())1 else 0) }
        content.addView(calendarSpinner)
        val lock=Switch(this).apply { text="فعال‌کردن قفل اثر انگشت / قفل دستگاه"; isChecked=prefs.getBoolean("biometric",false) }
        content.addView(lock)
        content.addView(button("ذخیره تنظیمات") {
            prefs.edit().putString("currency",currencies[currencySpinner.selectedItemPosition])
                .putBoolean("jalali",calendarSpinner.selectedItemPosition==1)
                .putBoolean("biometric",lock.isChecked).apply()
            toast("تنظیمات ذخیره شد")
            if(lock.isChecked && !prefs.getBoolean("biometric_was_on",false)) {
                prefs.edit().putBoolean("biometric_was_on",true).apply()
                authenticate()
            } else showHome()
        })
        content.addView(label("تاریخ‌ها در پایگاه داده به‌صورت میلادی ذخیره می‌شوند؛ نمایش و ورود تاریخ با انتخاب تقویم تغییر می‌کند.",13f))
    }

    private fun reportDialog(w:Worker) {
        val modes=arrayOf("ماهانه","سالانه")
        val mode=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,modes) }
        val year=EditText(this).apply { hint="سال (مثلاً 2026)"; setText(if(jalali()) persianCalendar().get(Calendar.YEAR).toString() else Calendar.getInstance().get(Calendar.YEAR).toString()); inputType=2 }
        val month=EditText(this).apply {
            hint=if(jalali()) "ماه شمسی (۱ تا ۱۲)" else "ماه میلادی (۱ تا ۱۲)"
            setText(if(jalali()) (persianCalendar().get(Calendar.MONTH)+1).toString() else (Calendar.getInstance().get(Calendar.MONTH)+1).toString())
            inputType=2
        }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),dp(8)); addView(mode); addView(year); addView(month) }
        val d=AlertDialog.Builder(this).setTitle("گزارش حساب ${w.name}").setView(box).setPositiveButton("نمایش",null).setNegativeButton("لغو",null).create()
        d.setOnShowListener { d.window?.setBackgroundDrawable(rounded(surface,22)); d.getButton(-1).setTextColor(teal); d.getButton(-1).setOnClickListener {
            val y=year.text.toString().toIntOrNull()
            val m=month.text.toString().toIntOrNull()
            if(y==null || (mode.selectedItemPosition==0 && (m==null || m !in 1..12))) { toast("سال یا ماه را درست وارد کنید"); return@setOnClickListener }
            val selected=db.works(w.id).filter { matchesPeriod(it.date,y,m,mode.selectedItemPosition==0) }
            val selectedPayments=db.payments(w.id).filter { matchesPeriod(it.date,y,m,mode.selectedItemPosition==0) }
            val workEntries=selected.filterNot { isHoliday(it) }
            val holidays=selected.count { isHoliday(it) }
            val earned=workEntries.sumOf { it.wage+(it.wage*it.overtime/8.0).toLong() }
            val received=selectedPayments.sumOf { it.amount }
            val workDays=workEntries.map { it.date }.distinct().size
            val overtimeHours=workEntries.sumOf { it.overtime }
            val period=if(mode.selectedItemPosition==0) "ماه $m سال $y" else "سال $y"
            AlertDialog.Builder(this).setTitle("گزارش کار و حساب $period")
                .setMessage("شخص: ${w.name}\nتعداد روزهای کاری: $workDays روز\nروزهای تعطیل: $holidays روز\nتعداد رکوردهای کارکرد: ${selected.size}\nمجموع اضافه‌کاری: ${"%.2f".format(Locale.US,overtimeHours)} ساعت\nجمع کارکرد: ${fmt(earned)} ${w.currency}\nجمع دریافتی: ${fmt(received)} ${w.currency}\nمانده این دوره: ${fmt(earned-received)} ${w.currency}")
                .setPositiveButton("بستن",null).show()
            d.dismiss()
        } }
        d.show()
    }

    // Android ICU locale extension selects the Persian (Jalali) calendar without an extra library.
    private fun persianCalendar(): Calendar =
        Calendar.getInstance(Locale.forLanguageTag("fa-IR-u-ca-persian"))

    private fun matchesPeriod(iso:String, year:Int, month:Int?, monthly:Boolean):Boolean {
        return try {
            val c=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)!!
            if(jalali()) {
                val pc=persianCalendar().apply { time=c }
                pc.get(Calendar.YEAR)==year && (!monthly || pc.get(Calendar.MONTH)+1==month)
            } else {
                val cal=Calendar.getInstance().apply { time=c }
                cal.get(Calendar.YEAR)==year && (!monthly || cal.get(Calendar.MONTH)+1==month)
            }
        } catch(_:Exception){false}
    }

    private fun dateHint()=if(jalali()) "تاریخ شمسی YYYY-MM-DD" else "تاریخ میلادی YYYY-MM-DD"
    private fun todayForInput():String = if(jalali()) dateForInput(today()) else today()
    private fun dateForInput(iso:String):String {
        val raw=if(!jalali()) iso.replace('-','/') else try {
            val dt=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)!!
            val pc=persianCalendar().apply { time=dt }
            String.format(Locale.US,"%04d/%02d/%02d",pc.get(Calendar.YEAR),pc.get(Calendar.MONTH)+1,pc.get(Calendar.DAY_OF_MONTH))
        } catch(_:Exception){iso.replace('-','/')}
        return raw.map { if(it in '0'..'9') ('۰'.code + (it-'0')).toChar() else it }.joinToString("")
    }
    private fun toGregorian(value:String):String {
        val ascii=value.map { ch -> when(ch) { in '۰'..'۹' -> ('0'.code + (ch-'۰')).toChar(); in '٠'..'٩' -> ('0'.code + (ch-'٠')).toChar(); else -> ch } }.joinToString("").replace('/','-')
        return try {
            val p=ascii.split("-"); require(p.size==3)
            if(!jalali()) String.format(Locale.US,"%04d-%02d-%02d",p[0].toInt(),p[1].toInt(),p[2].toInt()) else {
                val pc=persianCalendar().apply { clear(); set(Calendar.YEAR,p[0].toInt()); set(Calendar.MONTH,p[1].toInt()-1); set(Calendar.DAY_OF_MONTH,p[2].toInt()) }
                SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(pc.timeInMillis))
            }
        } catch(_:Exception){ascii}
    }
    private fun dateLabel(iso:String):String {
        return try {
            val date=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)!!
            val day=SimpleDateFormat("EEEE",Locale("fa")).format(date)
            val greg=iso.replace('-', '/').map { if(it in '0'..'9') ('۰'.code + (it-'0')).toChar() else it }.joinToString("")
            val jal=try {
                val pc=persianCalendar().apply { time=date }
                String.format(Locale.US,"%04d/%02d/%02d",pc.get(Calendar.YEAR),pc.get(Calendar.MONTH)+1,pc.get(Calendar.DAY_OF_MONTH)).map { if(it in '0'..'9') ('۰'.code + (it-'0')).toChar() else it }.joinToString("")
            } catch(_:Exception) { "" }
            "$jal | $greg ($day)"
        } catch(_:Exception){iso}
    }

    private fun projectSpinner(selectedId:Long?=null):Spinner {
        val projects=db.projects()
        val names=listOf("بدون پروژه") + projects.map{it.name}
        return Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,names)
            setSelection(if(selectedId==null) 0 else (projects.indexOfFirst{it.id==selectedId}+1).coerceAtLeast(0))
        }
    }
    private fun selectedProject(spinner:Spinner):Long? {
        val projects=db.projects()
        return projects.getOrNull(spinner.selectedItemPosition-1)?.id
    }

    private fun batchWorkDialog() {
        val people=db.workers()
        if(people.isEmpty()) { toast("ابتدا شخص اضافه کنید"); return }
        val checks=people.map { w -> CheckBox(this).apply { text=w.name; tag=w.id } }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; checks.forEach { addView(it) } }
        val scroll=ScrollView(this).apply { addView(box) }
        val wrapper=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(scroll,LinearLayout.LayoutParams(-1,dp(180))) }
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val project=projectSpinner()
        val start=EditText(this).apply { hint="ساعت شروع، مثلاً 07:00" }
        val end=EditText(this).apply { hint="ساعت پایان، مثلاً 16:00" }
        val wage=EditText(this).apply { hint="دستمزد یک روز (۸ ساعت)"; inputType=2 }
        val ot=EditText(this).apply { hint="اضافه‌کاری به ساعت"; inputType=8194; setText("0") }
        val note=EditText(this).apply { hint="توضیحات (اختیاری)" }
        val holiday=CheckBox(this).apply { text="این روز تعطیل است"; setTextColor(Color.rgb(255,75,85)) }
        holiday.setOnCheckedChangeListener { _, checked ->
            listOf(start,end,wage,ot,note).forEach { it.isEnabled=!checked; it.alpha=if(checked) 0.45f else 1f }
            if(checked) note.setText("تعطیل") else if(note.text.toString()=="تعطیل") note.setText("")
        }
        listOf(date,project,holiday,start,end,wage,ot,note).forEach { wrapper.addView(it) }
        formDialog("ثبت یکسان برای چند شخص",listOf(wrapper)) {
            val ids=checks.filter { it.isChecked }.map { it.tag as Long }
            val amount=if(holiday.isChecked) 0L else wage.text.toString().toLongOrNull()
            val extra=if(holiday.isChecked) 0.0 else ot.text.toString().toDoubleOrNull()
            if(ids.isEmpty() || amount==null || extra==null || date.text.isBlank()) { toast("اشخاص، تاریخ، دستمزد و اضافه‌کاری را بررسی کنید"); false }
            else { db.addWorks(ids,toGregorian(date.text.toString()),if(holiday.isChecked) "" else start.text.toString(),if(holiday.isChecked) "" else end.text.toString(),amount,extra,if(holiday.isChecked) "تعطیل" else note.text.toString(),selectedProject(project)); showHome(); true }
        }
    }
    private fun workDialog(ids:List<Long>) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val project=projectSpinner()
        val start=EditText(this).apply { hint="ساعت شروع" }; val end=EditText(this).apply { hint="ساعت پایان" }
        val wage=EditText(this).apply { hint="دستمزد روزانه (۸ ساعت)"; inputType=2 }
        val ot=EditText(this).apply { hint="اضافه‌کاری به ساعت"; inputType=8194; setText("0") }
        val note=EditText(this).apply { hint="توضیحات" }
        val holiday=CheckBox(this).apply { text="این روز تعطیل است"; setTextColor(Color.rgb(255,75,85)) }
        holiday.setOnCheckedChangeListener { _, checked ->
            listOf(start,end,wage,ot,note).forEach { it.isEnabled=!checked; it.alpha=if(checked) 0.45f else 1f }
            if(checked) note.setText("تعطیل") else if(note.text.toString()=="تعطیل") note.setText("")
        }
        formDialog("ثبت کارکرد",listOf(date,project,holiday,start,end,wage,ot,note)) {
            val amount=if(holiday.isChecked) 0L else wage.text.toString().toLongOrNull()
            val extra=if(holiday.isChecked) 0.0 else ot.text.toString().toDoubleOrNull()
            if(amount==null || date.text.isBlank() || extra==null) { toast("تاریخ، دستمزد و اضافه‌کاری را بررسی کنید"); false }
            else { db.addWorks(ids,toGregorian(date.text.toString()),if(holiday.isChecked) "" else start.text.toString(),if(holiday.isChecked) "" else end.text.toString(),amount,extra,if(holiday.isChecked) "تعطیل" else note.text.toString(),selectedProject(project)); currentWorker?.let { showWorker(it) } ?: showHome(); true }
        }
    }
    private fun editWorkDialog(w:Work, person:Worker) {
        val date=EditText(this).apply { hint=dateHint(); setText(dateForInput(w.date)) }
        val project=projectSpinner(w.projectId)
        val start=EditText(this).apply { setText(w.start); hint="شروع" }; val end=EditText(this).apply { setText(w.end); hint="پایان" }
        val wage=EditText(this).apply { setText(w.wage.toString()); inputType=2 }
        val ot=EditText(this).apply { setText(w.overtime.toString()); inputType=8194 }
        val note=EditText(this).apply { setText(if(isHoliday(w)) "" else w.note) }
        val holiday=CheckBox(this).apply { text="این روز تعطیل است"; setTextColor(Color.rgb(255,75,85)); isChecked=isHoliday(w) }
        holiday.setOnCheckedChangeListener { _, checked ->
            listOf(start,end,wage,ot,note).forEach { it.isEnabled=!checked; it.alpha=if(checked) 0.45f else 1f }
            if(checked) note.setText("تعطیل") else if(note.text.toString()=="تعطیل") note.setText("")
        }
        listOf(start,end,wage,ot,note).forEach { it.isEnabled=!holiday.isChecked; it.alpha=if(holiday.isChecked) 0.45f else 1f }
        formDialog("ویرایش کارکرد",listOf(date,project,holiday,start,end,wage,ot,note)) {
            val amount=if(holiday.isChecked) 0L else wage.text.toString().toLongOrNull()
            val extra=if(holiday.isChecked) 0.0 else ot.text.toString().toDoubleOrNull()
            if(amount==null || extra==null || date.text.isBlank()) { toast("اطلاعات را بررسی کنید"); false }
            else { db.updateWork(w.copy(date=toGregorian(date.text.toString()),start=if(holiday.isChecked) "" else start.text.toString(),end=if(holiday.isChecked) "" else end.text.toString(),wage=amount,overtime=extra,note=if(holiday.isChecked) "تعطیل" else note.text.toString(),projectId=selectedProject(project))); showWorker(person); true }
        }
    }
    private fun paymentWorkerDialog() {
        val people=db.workers(); if(people.isEmpty()){toast("ابتدا شخص اضافه کنید");return}
        val names=people.map{it.name}.toTypedArray()
        AlertDialog.Builder(this).setTitle("انتخاب شخص").setItems(names){_,i->paymentDialog(people[i])}.setNegativeButton("لغو",null).show().window?.setBackgroundDrawable(rounded(surface,20))
    }
    private fun paymentDialog(w:Worker) {
        val date=EditText(this).apply { hint=dateHint(); setText(todayForInput()) }
        val amount=EditText(this).apply { hint="مبلغ دریافتی"; inputType=2 }
        val note=EditText(this).apply { hint="توضیحات" }
        val project=projectSpinner()
        formDialog("ثبت دریافتی برای ${w.name}",listOf(date,amount,project,note)) {
            val v=amount.text.toString().toLongOrNull()
            if(v==null || date.text.isBlank()) { toast("تاریخ و مبلغ را وارد کنید"); false } else { db.addPayment(w.id,toGregorian(date.text.toString()),v,note.text.toString(),selectedProject(project)); currentWorker?.let{showWorker(it)} ?: showHome(); true }
        }
    }
    private fun formDialog(title:String, views:List<View>, save:()->Boolean) {
        views.forEach { v ->
            if(v is EditText) {
                v.setPadding(dp(13),dp(11),dp(13),dp(11)); v.textSize=15f
                v.setTextColor(ink); v.setHintTextColor(muted); v.background=rounded(surfaceAlt,14)
                v.textDirection=View.TEXT_DIRECTION_RTL
            }
            if(v is Spinner) { v.background=rounded(surfaceAlt,14); v.setPadding(dp(8),dp(5),dp(8),dp(5)) }
        }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(4)); views.forEach { v -> addView(v,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(7) }) } }
        val scroll=ScrollView(this).apply { addView(box) }
        val d=AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("ذخیره",null).setNegativeButton("لغو",null).create()
        d.setOnShowListener { d.window?.setBackgroundDrawable(rounded(surface,22)); d.getButton(-1).setTextColor(teal); d.getButton(-2).setTextColor(Color.GRAY); d.getButton(-1).setOnClickListener { if(save()) d.dismiss() } }
        d.show()
    }
    private fun confirm(message:String, yes:()->Unit) { val d=AlertDialog.Builder(this).setMessage(message).setPositiveButton("تأیید"){_,_->yes()}.setNegativeButton("لغو",null).create(); d.setOnShowListener { d.window?.setBackgroundDrawable(rounded(surface,22)); d.getButton(-1).setTextColor(teal) }; d.show() }
    private fun exportPdf(w:Worker) {
        try {
            val pdf=PdfDocument(); val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize=12f; color=Color.BLACK }
            var pageNo=1; var y=50
            var page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create())
            fun line(s:String) { if(y>790){pdf.finishPage(page);pageNo++;page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());y=50}; page.canvas.drawText(s,35f,y.toFloat(),paint); y+=24 }
            line("Daftar Karkard - ${w.name}"); line("Total work: ${fmt(db.total(w.id))} ${w.currency}"); line("Received: ${fmt(db.paid(w.id))} ${w.currency}"); line("Balance: ${fmt(db.total(w.id)-db.paid(w.id))} ${w.currency}"); line("-----------------------------------------------")
            db.works(w.id).forEach { item ->
                if(isHoliday(item)) line("${item.date} | تعطیل")
                else line("${item.date} | wage ${item.wage} | overtime ${item.overtime} h | ${item.start}-${item.end}")
            }
            line("Payments"); db.payments(w.id).forEach { line("${it.date} | ${it.amount} | ${it.note}") }
            pdf.finishPage(page)
            val name="Daftar-${w.name}-${System.currentTimeMillis()}.pdf"
            val values=android.content.ContentValues().apply { put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name); put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/pdf"); put(android.provider.MediaStore.Downloads.RELATIVE_PATH,android.os.Environment.DIRECTORY_DOWNLOADS) }
            val uri=contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values) ?: throw IOException("Cannot create PDF")
            contentResolver.openOutputStream(uri).use { pdf.writeTo(it!!) }; pdf.close(); toast("PDF در پوشه Downloads ذخیره شد")
        } catch(e:Exception){toast("ساخت PDF ناموفق بود: ${e.message}")}
    }
    private fun createBackup(){
        if(saveSingleBackup()) toast("پشتیبان به‌روزرسانی شد؛ نسخه قبلی جایگزین شد")
        else toast("تهیه پشتیبان ناموفق بود")
    }

    // Keep exactly one rolling backup file; each run overwrites the previous copy.
    private fun saveSingleBackup():Boolean {
        return try {
            db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use { c -> if(c.moveToFirst() && c.getInt(0)!=0) throw IOException("Database checkpoint is busy") }
            val databaseFile=getDatabasePath("daftar_native.db")
            if(!databaseFile.exists()) throw IOException("Database file not found")
            if(android.os.Build.VERSION.SDK_INT >= 29) {
                val resolver=contentResolver
                val collection=android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val name="daftar-karkard-backup.db"
                val relative=android.os.Environment.DIRECTORY_DOWNLOADS + "/DaftarKarkard/"
                val projection=arrayOf(android.provider.MediaStore.MediaColumns._ID)
                val selection=android.provider.MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+android.provider.MediaStore.MediaColumns.RELATIVE_PATH+"=?"
                val existing=resolver.query(collection,projection,selection,arrayOf(name,relative),null)
                var target:Uri?=null
                existing?.use { c -> if(c.moveToFirst()) target=Uri.withAppendedPath(collection,c.getLong(0).toString()) }
                if(target==null) {
                    val values=android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,name)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE,"application/octet-stream")
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,relative)
                    }
                    target=resolver.insert(collection,values)
                }
                val uri=target ?: throw IOException("Cannot create backup destination")
                resolver.openOutputStream(uri,"wt").use { out ->
                    if(out==null) throw IOException("Cannot open backup destination")
                    databaseFile.inputStream().use { it.copyTo(out) }
                }
            } else {
                val dir=File(getExternalFilesDir(null) ?: filesDir,"backups")
                if(!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create backup folder")
                val target=File(dir,"daftar-karkard-backup.db")
                databaseFile.inputStream().use { input -> target.outputStream().use { input.copyTo(it) } }
            }
            true
        } catch(e:Exception) { android.util.Log.e("DaftarKarkard","Backup failed",e); false }
    }

    private fun restoreBackup(){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"};startActivityForResult(i,restoreReq) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return
        try { if(requestCode==backupReq){ val f=getDatabasePath("daftar_native.db"); contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { input -> input.copyTo(out) } } ?: throw IOException("Cannot open destination"); toast("پشتیبان ذخیره شد") }
            else if(requestCode==restoreReq){ val temp=File(filesDir,"restore.db"); contentResolver.openInputStream(uri)!!.use{input->temp.outputStream().use{input.copyTo(it)}}; db.close(); temp.copyTo(getDatabasePath("daftar_native.db"),true); db=Db(this); showHome(); toast("بازیابی انجام شد") }
        }catch(e:Exception){toast("خطا: ${e.message}")}}
    private fun fmt(v:Long)=String.format(Locale.US,"%,d",v)
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
